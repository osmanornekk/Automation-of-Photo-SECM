import sys
import os
import numpy as np
import time
import shutil

# Get the parent directory and add it to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import aespm as ae
# Now you can import AFMController
from lbni_controller import AFMController

# Define scan parameters in meters
scan_size = 60e-6      # 20 um in meters
spacing = 15e-6         # 1 um in meters

x_points = np.arange(0, scan_size + spacing, spacing)
y_points = np.arange(0, scan_size + spacing, spacing)

coordinates = [(x, y) for x in x_points for y in y_points]


def main():
    # Path to the project
    project_path = r"C:\Users\adminlnet\OpenSPM-source"
    
    afm = AFMController(project_path)
    #afm.scan_control.set_xyposition(x, y, forced=True)
    #afm.scan_parameters.set_width(1*10-12)
    #afm.scan_parameters.set_scan_speed(1000000) 

    for x, y in coordinates:
        afm.scan_control.set_xyposition(x, y, forced=True)
        time.sleep(3)  # Wait for the AFM to move to the new position 
        
        # Collect as many values as possible in 1 second
        values = []
        start_time = time.time()
        while time.time() - start_time < 1.0:
            value = afm.signals.get_vertical_deflection()
            values.append(value)
        
        print(f"Position: ({x:.2e}, {y:.2e}), Vertical Deflection values ({len(values)} samples):")
        print(values)

    afm.disconnect()
    print("\n--- AFM disconnected ---")
    
if __name__ == "__main__":
    main()

