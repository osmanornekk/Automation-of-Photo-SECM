import sys
import os
import time
# Get the parent directory and add it to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import aespm as ae
# Now you can import AFMController
from lbni_controller import AFMController

def main():
    # Path to the project
    project_path = r"C:\Users\adminlnet\OpenSPM-source"
    
    afm = AFMController(project_path)
       # Please skip this step if you prefer setting the initial parameters manually 
    print("\n--- Scanning starts... ---")

 
    #afm.scan_control.set_path(r"D:\AFM temp data\2025-05-09_exp00")
    #afm.scan_control.set_file_name("osman1")
    #a = afm.scan_control.get_file_name()
    #print(a)
    #afm.scan_control.scan_auto_save(True)
   # afm.scan_control.scan_up()
    # wait 7 sec
    #time.sleep(7)
    #afm.scan_control.scan_save_now()
    #afm.scan_control.scan_auto_save(True)
    #f = afm.scan_control.isAutoSave()
    #print(f)
    #afm.scan_control.scan_stop()

    #afm.scan_control.scan_save_now()



    import os
    import time

    # 1. Kaydetme yolu ve dosya adı belirleniyor
    path = r"D:\AFM temp data\2025-05-21_exp00"
    file_name = "osman1"
    #path = r"D:\AFM_temp_data\2025_05_14_exp00"  # Boşluklardan kaçındık, alt çizgi kullandık
    #file_name = "osman1"  # Sadece harf ve sayı
    ff = afm.scan_control.get_path()
    print("Set path to:", ff)
    print("Set file name to:", afm.scan_control.get_file_name())
    # 1.a. Eğer klasör yoksa oluştur
    #os.makedirs(path, exist_ok=True)

    # 1.b. Path ve dosya adı AFM cihazına aktarılıyor
    #afm.scan_control.set_path(path)
    #afm.scan_control.set_file_name(file_name)


    #print("Auto Save on?:", afm.scan_control.isAutoSave())


    # 2. (İsteğe bağlı) Otomatik kaydetme açılabilir
    #afm.scan_control.scan_auto_save(True)
    #print("Auto Save on?:", afm.scan_control.isAutoSave())
    # 3. Taramayı başlat (örneğin yukarı yönde)
    afm.scan_control.scan_down()
    dd = afm.scan_control.get_total_time()
    print(dd)
    cc = afm.scan_control.get_time_to_finish()
    print(cc)
    # 4. Belirli süre tarama yapılır
    #time.sleep(7)

    import matplotlib.pyplot as plt
    import time

    plt.ion()  # Interactive mode ON

    # İlk veri çekme
    img_e = afm.image.get_channel("Error", 0)

    # Plot oluştur
    fig, ax = plt.subplots()
    im = ax.imshow(img_e, cmap='viridis')
    plt.colorbar(im)
    plt.title("Canlı img_e Güncellemesi")

    for i in range(4):
        print(afm.scan_control.get_time_to_finish())
        print(afm.scan_control.get_line())

        img_e = afm.image.get_channel("Error", 0)

        im.set_data(img_e)  # Görseli güncelle
        plt.draw()
        plt.pause(0.1)      # Yenileme hızı (gerekirse ayarla)

        time.sleep(0.4)

    
    plt.ioff()



    # 5. Taramayı durdur
    afm.scan_control.scan_stop()

    cc = afm.scan_control.get_time_to_finish()
    print(cc)

    # 6. Manuel kayıt yapılır (Auto Save açık değilse)
    afm.scan_control.scan_save_now()

    # 7. (Opsiyonel) Auto Save açık mı kontrol et
    # print("Auto Save on?:", afm.scan_control.isAutoSave())


'''
    print("\n--- Scanning stopped.. ---")
    abc = afm.scan_parameters.get_scan_speed()
    print(abc)
    print(afm.scan_parameters.get_width())

    #path2 = r"D:\AFM temp data\2025-06-01_exp00_trial"
    #afm.scan_control.set_path(path2)
    print(afm.scan_control.get_path())
    file_name1 = "osman1"
    afm.scan_control.set_file_name(file_name1)
    print(afm.scan_control.get_file_name())
    print(afm.image.get_channels_names())
    print(img_e)
    #afm.scan_parameters.set_xyposition(x, y)
'''



'''
    # Set the scan parameters for the exploration
    # Please skip this step if you prefer setting the initial parameters manually 
    print("\n--- Setting Scan Parameters ---")

    afm.scan_parameters.set_width(4e-6)
    afm.scan_parameters.set_offset_x(8e-6)
    afm.scan_parameters.set_offset_y(10e-6)
    afm.scan_parameters.set_scan_speed(4)
    
    print("\n--- Scan Parameters set ---")
    
    # Step N: Disconnect from the AFM system
    afm.disconnect()
    print("\n--- AFM disconnected ---")
'''

if __name__ == "__main__":
    main()