""" Bio-Logic OEM package python API.

Example script to run a Chronoamperometry (CA) experiment using the EC-Lab OEM Package library.
Follows the same data format and conversion as the CP example.
"""

import os
import sys
import time
from dataclasses import dataclass

import kbio.kbio_types as KBIO
from kbio.c_utils import c_is_64b
from kbio.kbio_api import KBIO_api
from kbio.kbio_tech import ECC_parm
from kbio.kbio_tech import get_experiment_data
from kbio.kbio_tech import get_info_data
from kbio.kbio_tech import make_ecc_parm
from kbio.kbio_tech import make_ecc_parms
from kbio.utils import exception_brief

# ------------------------------------------------------------------------------

verbosity = 1

address = "192.109.209.128"
channel = 1
binary_path = "C:/EC-Lab Development Package/lib"
force_load_firmware = True

ca3_tech_file = "ca.ecc"
ca4_tech_file = "ca4.ecc"
ca5_tech_file = "ca5.ecc"

repeat_count = 4  # Number of cycles to repeat the experiment
record_dt = 0.01  # seconds
record_dI = 0.0000000000010  # Amps (set to 0 to disable, or >0 to enable)
i_range = "I_RANGE_100uA"

# CA parameters (adjust as needed)
@dataclass
class ca_step:
    voltage: float
    duration: float
    vs_init: bool = False

# Example steps (add up to 100 if needed)
steps = [
    ca_step(0.2, .01),      # 0.2 V for 2 s, vs initial
    ca_step(0, .01, True),       # 0.5 V for 1 s
 #   ca_step(-0.1, 3),     # -0.1 V for 3 s
 #   ca_step(0.5, 1, True) # 0.5 V for 1 s, vs initial
]

CA_parms = {
    "voltage_step": ECC_parm("Voltage_step", float),
    "duration_step": ECC_parm("Duration_step", float),
    "vs_init": ECC_parm("vs_initial", bool),
    "nb_steps": ECC_parm("Step_number", int),
    "record_dt": ECC_parm("Record_every_dT", float),
    "record_dI": ECC_parm("Record_every_dI", float),
    "repeat": ECC_parm("N_Cycles", int),
    "I_range": ECC_parm("I_Range", int),
}

def newline():
    print()

def print_exception(e):
    print(f"{exception_brief(e, verbosity>=2)}")

if c_is_64b:
    DLL_file = "EClib64.dll"
else:
    DLL_file = "EClib.dll"

DLL_path = f"{binary_path}{os.sep}{DLL_file}"

try:
    newline()
    api = KBIO_api(DLL_path)
    version = api.GetLibVersion()
    print(f"> EcLib version: {version}")
    newline()

    id_, device_info = api.Connect(address)
    print(f"> device[{address}] info :")
    print(device_info)
    newline()

    board_type = api.GetChannelBoardType(id_, channel)
    match board_type:
        case KBIO.BOARD_TYPE.ESSENTIAL.value:
            firmware_path = "kernel.bin"
            fpga_path = "Vmp_ii_0437_a6.xlx"
        case KBIO.BOARD_TYPE.PREMIUM.value:
            firmware_path = "kernel4.bin"
            fpga_path = "vmp_iv_0395_aa.xlx"
        case KBIO.BOARD_TYPE.DIGICORE.value:
            firmware_path = "kernel.bin"
            fpga_path = ""
        case _:
            print("> Board type detection failed")
            sys.exit(-1)

    print(f"> Loading {firmware_path} ...")
    channel_map = api.channel_map({channel})
    api.LoadFirmware(id_, channel_map, firmware=firmware_path, fpga=fpga_path, force=force_load_firmware)
    print("> ... firmware loaded")
    newline()

    channel_info = api.GetChannelInfo(id_, channel)
    print(f"> Channel {channel} info :")
    print(channel_info)
    newline()

    if not channel_info.is_kernel_loaded:
        print("> kernel must be loaded in order to run the experiment")
        sys.exit(-1)

    match board_type:
        case KBIO.BOARD_TYPE.ESSENTIAL.value:
            tech_file = ca3_tech_file
        case KBIO.BOARD_TYPE.PREMIUM.value:
            tech_file = ca4_tech_file
        case KBIO.BOARD_TYPE.DIGICORE.value:
            tech_file = ca5_tech_file
        case _:
            print("> Board type detection failed")
            sys.exit(-1)

    # Define CA steps
    p_steps = []
    for idx, step in enumerate(steps):
        p_steps.append(make_ecc_parm(api, CA_parms["voltage_step"], step.voltage, idx))
        p_steps.append(make_ecc_parm(api, CA_parms["duration_step"], step.duration, idx))
        p_steps.append(make_ecc_parm(api, CA_parms["vs_init"], step.vs_init, idx))

    # Step_number is number of steps minus 1
    p_nb_steps = make_ecc_parm(api, CA_parms["nb_steps"], len(steps) - 1)
    p_record_dt = make_ecc_parm(api, CA_parms["record_dt"], record_dt)
    p_record_dI = make_ecc_parm(api, CA_parms["record_dI"], record_dI)
    p_repeat = make_ecc_parm(api, CA_parms["repeat"], repeat_count)
    p_I_range = make_ecc_parm(api, CA_parms["I_range"], KBIO.I_RANGE[i_range].value)

    ecc_parms = make_ecc_parms(
        api,
        *p_steps,
        p_nb_steps,
        p_record_dt,
        p_record_dI,
        p_I_range,
        p_repeat
    )

    api.LoadTechnique(id_, channel, tech_file, ecc_parms, first=True, last=True, display=(verbosity > 1))
    api.StartChannel(id_, channel)

    # Data conversion helpers
    def hex_to_signed_int32(h):
        v = int(h, 16)
        if v >= 2**31:
            v -= 2**32
        return v

    # Example pixel grid (replace with your actual scan pattern)
    pixel_grid = [(i, j) for i in range(3) for j in range(3)]  # 3x3 grid as example

    for pixel_idx, (i, j) in enumerate(pixel_grid):
        print(f"\n--- Starting pixel ({i}, {j}) [{pixel_idx+1}/{len(pixel_grid)}] ---")

        # --- Move to pixel position (implement your own stage/piezo control here) ---
        # move_to_pixel(i, j)

        # --- Prepare CA parameters for this pixel if needed (steps, etc.) ---

        # Re-create parameter objects for each pixel (if needed)
        p_steps = []
        for idx, step in enumerate(steps):
            p_steps.append(make_ecc_parm(api, CA_parms["voltage_step"], step.voltage, idx))
            p_steps.append(make_ecc_parm(api, CA_parms["duration_step"], step.duration, idx))
            p_steps.append(make_ecc_parm(api, CA_parms["vs_init"], step.vs_init, idx))

        p_nb_steps = make_ecc_parm(api, CA_parms["nb_steps"], len(steps) - 1)
        p_record_dt = make_ecc_parm(api, CA_parms["record_dt"], record_dt)
        p_record_dI = make_ecc_parm(api, CA_parms["record_dI"], record_dI)
        p_repeat = make_ecc_parm(api, CA_parms["repeat"], repeat_count)
        p_I_range = make_ecc_parm(api, CA_parms["I_range"], KBIO.I_RANGE[i_range].value)

        ecc_parms = make_ecc_parms(
            api,
            *p_steps,
            p_nb_steps,
            p_record_dt,
            p_record_dI,
            p_I_range,
            p_repeat
        )

        # --- Load and start the technique for this pixel ---
        api.LoadTechnique(id_, channel, tech_file, ecc_parms, first=True, last=True, display=(verbosity > 1))
        api.StartChannel(id_, channel)

        # --- Data collection for this pixel ---
        ca_filename = f"ca_pixel_{i}_{j}.csv"
        csvfile = open(ca_filename, "w")
        csvfile.write("t (s),Ewe (V),Iwe (A),Cycle (N)\n")
        count = 0
        print("> Reading data ", end="", flush=True)
        while True:
            data = api.GetData(id_, channel)
            status, tech_name = get_info_data(api, data)
            print(".", end="", flush=True)

            for output in get_experiment_data(api, data, tech_name, board_type):
                if len(output) != 5:
                    print(f"Unexpected output length: {len(output)}. Skipping this output.")
                    continue
                t_raw, ewe_raw, iwe_raw, _, cycle_raw = output
                t = int(t_raw, 16) * 1e-6  # seconds
                Ewe = hex_to_signed_int32(ewe_raw) * 1e-6  # volts
                Iwe = api.ConvertChannelNumericIntoSingle(int(iwe_raw, 16), board_type)
                cycle = int(cycle_raw, 16)
                csvfile.write(f"{t},{Ewe},{Iwe},{cycle}\n")
                csvfile.flush()
                count += 1

            if status == "STOP":
                break

            time.sleep(1)

        csvfile.close()
        print(f"\n> {count} data have been written into {ca_filename}")
        print("> Pixel experiment done")

    print("> experiment done")
    newline()

    api.Disconnect(id_)

except KeyboardInterrupt:
    print(".. interrupted")

except Exception as e:
    print_exception(e)