import easy_biologic as ebl
import easy_biologic.base_programs as blp        

bl = ebl.BiologicDevice('192.109.209.128')
save_path = '/Desktop/CV.csv'
params = {
    'start': 0.5,
    'end': -0.25,
    'E2': 0.8,
    'Ef': 1.0,
    'rate': 0.05,  
    'step': 0.001,    
    'N_Cycles': 2,
    'begin_measuring_I': 0.5,
    'End_measuring_I': 1.0,
}  

CV = blp.CV(
    bl,
    params,     
    channels = [0]
)     

CV.run('data')
CV.save_data(save_path)