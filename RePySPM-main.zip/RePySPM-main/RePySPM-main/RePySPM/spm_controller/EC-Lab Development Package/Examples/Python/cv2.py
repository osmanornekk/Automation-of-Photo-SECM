import os
import sys
import time
from dataclasses import dataclass

import kbio.kbio_types as KBIO
from kbio.c_utils import c_is_64b
from kbio.kbio_api import KBIO_api
from kbio.kbio_tech import ECC_parm
from kbio.kbio_tech import get_experiment_data
from kbio.kbio_tech import get_info_data
from kbio.kbio_tech import make_ecc_parm
from kbio.kbio_tech import make_ecc_parms
from kbio.utils import exception_brief

# ------------------------------------------------------------------------------
def hex_to_signed_int32(h):
    v = int(h, 16)
    if v >= 2**31:
        v -= 2**32
    return v
verbosity = 1

address = "192.109.209.128"
channel = 1
binary_path = "C:/EC-Lab Development Package/lib"
force_load_firmware = True

cv3_tech_file = "cv.ecc"
cv4_tech_file = "cv4.ecc"
cv5_tech_file = "cv5.ecc"

# CV parameter values (adjust as needed)
vs_initial = [False, False, False, False, False]  # Array of 5 boolean
Voltage_step = [0.0, 0, 0.5, 0.0, 0.5]         # Array of 5 float (Ei, E1, E2, Ei, Ef)
Scan_Rate = [.1, 0.1, 0.1, 0.1, 0.1]             # Array of 5 float (V/s)
Scan_number = 2                                   # integer, must be 2
Record_every_dE = 0.01                            # float, V
Average_over_dE = False                           # boolean
N_Cycles = 3                                      # integer
Begin_measuring_I = 0                           # float, [0..1]
End_measuring_I = 1                            # float, [0..1]
i_range = "I_RANGE_100uA"  # or another valid range from KBIO.I_RANGE

CV_parms = {
    "vs_initial": ECC_parm("vs_initial", bool),
    "Voltage_step": ECC_parm("Voltage_step", float),
    "Scan_Rate": ECC_parm("Scan_Rate", float),
    "Scan_number": ECC_parm("Scan_number", int),
    "Record_every_dE": ECC_parm("Record_every_dE", float),
    "Average_over_dE": ECC_parm("Average_over_dE", bool),
    "N_Cycles": ECC_parm("N_Cycles", int),
    "Begin_measuring_I": ECC_parm("Begin_measuring_I", float),
    "End_measuring_I": ECC_parm("End_measuring_I", float),
    "I_range": ECC_parm("I_Range", int),  
}

if c_is_64b:
    DLL_file = "EClib64.dll"
else:
    DLL_file = "EClib.dll"

DLL_path = f"{binary_path}{os.sep}{DLL_file}"

try:
    print()

    api = KBIO_api(DLL_path)
    version = api.GetLibVersion()
    print(f"> EcLib version: {version}\n")

    id_, device_info = api.Connect(address)
    print(f"> device[{address}] info :")
    print(device_info)
    print()

    board_type = api.GetChannelBoardType(id_, channel)
    match board_type:
        case KBIO.BOARD_TYPE.ESSENTIAL.value:
            firmware_path = "kernel.bin"
            fpga_path = "Vmp_ii_0437_a6.xlx"
        case KBIO.BOARD_TYPE.PREMIUM.value:
            firmware_path = "kernel4.bin"
            fpga_path = "vmp_iv_0395_aa.xlx"
        case KBIO.BOARD_TYPE.DIGICORE.value:
            firmware_path = "kernel.bin"
            fpga_path = ""
        case _:
            print("> Board type detection failed")
            sys.exit(-1)

    print(f"> Loading {firmware_path} ...")
    channel_map = api.channel_map({channel})
    api.LoadFirmware(id_, channel_map, firmware=firmware_path, fpga=fpga_path, force=force_load_firmware)
    print("> ... firmware loaded\n")

    channel_info = api.GetChannelInfo(id_, channel)
    print(f"> Channel {channel} info :")
    print(channel_info)
    print()

    if not channel_info.is_kernel_loaded:
        print("> kernel must be loaded in order to run the experiment")
        sys.exit(-1)

    match board_type:
        case KBIO.BOARD_TYPE.ESSENTIAL.value:
            tech_file = cv3_tech_file
        case KBIO.BOARD_TYPE.PREMIUM.value:
            tech_file = cv4_tech_file
        case KBIO.BOARD_TYPE.DIGICORE.value:
            tech_file = cv5_tech_file
        case _:
            print("> Board type detection failed")
            sys.exit(-1)
    print("> Using technique file:", tech_file)
    # Define parameters
    p_vs_initial = []
    for idx, val in enumerate(vs_initial):
            p_vs_initial.append(make_ecc_parm(api, CV_parms["vs_initial"], val, idx))    
    p_Voltage_step = []
    for idx, val in enumerate(Voltage_step):
        p_Voltage_step.append(make_ecc_parm(api, CV_parms["Voltage_step"], val, idx))

    p_Scan_Rate = []
    for idx, val in enumerate(Scan_Rate):
        p_Scan_Rate.append(make_ecc_parm(api, CV_parms["Scan_Rate"], val, idx))

    p_Scan_number = make_ecc_parm(api, CV_parms["Scan_number"], Scan_number)
    p_Record_every_dE = make_ecc_parm(api, CV_parms["Record_every_dE"], Record_every_dE)
    p_Average_over_dE = make_ecc_parm(api, CV_parms["Average_over_dE"], Average_over_dE)
    p_N_Cycles = make_ecc_parm(api, CV_parms["N_Cycles"], N_Cycles)
    p_Begin_measuring_I = make_ecc_parm(api, CV_parms["Begin_measuring_I"], Begin_measuring_I)
    p_End_measuring_I = make_ecc_parm(api, CV_parms["End_measuring_I"], End_measuring_I)
    print("> Parameters defined")
    p_I_range = make_ecc_parm(api, CV_parms["I_range"], KBIO.I_RANGE[i_range].value)

    ecc_parms = make_ecc_parms(
        api,
        *p_vs_initial,
        *p_Voltage_step,
        *p_Scan_Rate,
        p_Scan_number,
        p_Record_every_dE,
        p_Average_over_dE,
        p_N_Cycles,
        p_Begin_measuring_I,
        p_End_measuring_I,
        p_I_range
    )

    api.LoadTechnique(id_, channel, tech_file, ecc_parms, first=True, last=True, display=(verbosity > 1))
    api.StartChannel(id_, channel)

    csvfile = open("cv.csv", "w")
    csvfile.write("t (s),Ewe (V),Iwe (A),Cycle (N)\n")
    count = 0
    print("> Reading data ", end="", flush=True)
    while True:
        data = api.GetData(id_, channel)
        status, tech_name = get_info_data(api, data)
        print(".", end="", flush=True)

        
        for output in get_experiment_data(api, data, tech_name, board_type):
            print("DEBUG output:", output)
            if len(output) != 5:
                print(f"Unexpected output length: {len(output)}. Skipping this output.")
                continue
            t_high_raw, t_low_raw, i_raw, ewe_raw, cycle_raw = output
            t_numeric = (int(t_high_raw, 16) << 16) | int(t_low_raw, 16)
            t = api.ConvertTimeChannelNumericIntoSeconds([t_numeric], 1.0, board_type)           
            Iwe = api.ConvertChannelNumericIntoSingle(int(i_raw, 16), board_type)
            Ewe = api.ConvertChannelNumericIntoSingle(int(ewe_raw, 16), board_type)
            cycle = int(cycle_raw, 16)
            csvfile.write(f"{t},{Ewe},{Iwe},{cycle}\n")
            csvfile.flush()
            count += 1
        if status == "STOP":
            break

        time.sleep(0.5)

    csvfile.close()
    print()
    print(f"> {count} data have been written into cv.csv")
    print("> experiment done\n")

    api.Disconnect(id_)

except KeyboardInterrupt:
    print(".. interrupted")

except Exception as e:
    print(f"Exception: {exception_brief(e, verbosity>=2)}")