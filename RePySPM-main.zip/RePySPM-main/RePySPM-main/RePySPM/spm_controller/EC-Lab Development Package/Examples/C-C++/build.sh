pushd "$(dirname "$0")" > /dev/null
mkdir -p build
rm build/* -fr
pushd build > /dev/null
cmake ..
cmake --build . --config Debug
popd > /dev/null
popd > /dev/null 2>&1