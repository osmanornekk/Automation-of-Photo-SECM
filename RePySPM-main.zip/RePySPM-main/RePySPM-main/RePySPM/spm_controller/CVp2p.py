import sys
import os
sys.path.insert(0, r"D:\Downloads\RePySPM-main\RePySPM-main\RePySPM\spm_controller\EC-Lab Development Package\Examples\Python")
import time
import numpy as np
from datetime import datetime
from PyQt5 import QtWidgets, QtCore
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

# Import your EC-Lab and piezo classes
from mcl_piezo_lib import Madpiezo
import kbio.kbio_types as KBIO
from kbio.c_utils import c_is_64b
from kbio.kbio_api import KBIO_api
from kbio.kbio_tech import ECC_parm, get_experiment_data, get_info_data, make_ecc_parm, make_ecc_parms

def hex_to_signed_int32(h):
    v = int(h, 16)
    if v >= 2**31:
        v -= 2**32
    return v

class CVScanGUI(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CV Point to Point Scanning")
        self.resize(1800, 900)

        # --- Main horizontal layout ---
        self.main_layout = QtWidgets.QHBoxLayout(self)
        self.setLayout(self.main_layout)

        # --- Left: Parameters (vertical layout) ---
        self.param_widget = QtWidgets.QWidget()
        self.param_layout = QtWidgets.QVBoxLayout(self.param_widget)

        # --- Scan parameters ---
        scan_group = QtWidgets.QGroupBox("Scan Parameters")
        scan_layout = QtWidgets.QFormLayout(scan_group)
        self.len_x = QtWidgets.QSpinBox(); self.len_x.setValue(5); self.len_x.setFixedWidth(100); self.len_x.setMaximum(1024)
        self.len_y = QtWidgets.QSpinBox(); self.len_y.setValue(5); self.len_y.setFixedWidth(100); self.len_y.setMaximum(1024)
        self.x1 = QtWidgets.QDoubleSpinBox(); self.x1.setValue(0.0); self.x1.setFixedWidth(100)
        self.x2 = QtWidgets.QDoubleSpinBox(); self.x2.setValue(40.0); self.x2.setFixedWidth(100)
        self.y1 = QtWidgets.QDoubleSpinBox(); self.y1.setValue(0.0); self.y1.setFixedWidth(100)
        self.y2 = QtWidgets.QDoubleSpinBox(); self.y2.setValue(40.0); self.y2.setFixedWidth(100)
        self.wait_time = QtWidgets.QDoubleSpinBox(); self.wait_time.setValue(1.0); self.wait_time.setFixedWidth(100)
        scan_layout.addRow("Pixels X:", self.len_x)
        scan_layout.addRow("Pixels Y:", self.len_y)
        scan_layout.addRow("X1 (µm):", self.x1)
        scan_layout.addRow("X2 (µm):", self.x2)
        scan_layout.addRow("Y1 (µm):", self.y1)
        scan_layout.addRow("Y2 (µm):", self.y2)
        scan_layout.addRow("Wait after move (s):", self.wait_time)
        self.param_layout.addWidget(scan_group)

        # --- CV parameters ---
        cv_group = QtWidgets.QGroupBox("CV Parameters")
        cv_layout = QtWidgets.QFormLayout(cv_group)
        self.scan_rate = QtWidgets.QDoubleSpinBox(); self.scan_rate.setValue(0.1); self.scan_rate.setFixedWidth(100)
        self.n_cycles = QtWidgets.QSpinBox(); self.n_cycles.setValue(0); self.n_cycles.setFixedWidth(100)
        self.e_start = QtWidgets.QDoubleSpinBox(); self.e_start.setValue(0.0); self.e_start.setFixedWidth(100)
        self.e_vertex1 = QtWidgets.QDoubleSpinBox(); self.e_vertex1.setValue(0.5); self.e_vertex1.setFixedWidth(100)
        self.e_vertex2 = QtWidgets.QDoubleSpinBox(); self.e_vertex2.setValue(-0.5); self.e_vertex2.setFixedWidth(100)
        self.e_end = QtWidgets.QDoubleSpinBox(); self.e_end.setValue(0.0); self.e_end.setFixedWidth(100)
        self.record_every_de = QtWidgets.QDoubleSpinBox()
        self.record_every_de.setDecimals(6)
        self.record_every_de.setMinimum(1e-6)
        self.record_every_de.setValue(0.01)
        self.record_every_de.setFixedWidth(100)
        # --- I Range dropdown ---
        self.i_range_combo = QtWidgets.QComboBox()
        self.i_range_options = [
            ("100 pA", "I_RANGE_100pA"),
            ("1 nA", "I_RANGE_1nA"),
            ("10 nA", "I_RANGE_10nA"),
            ("100 nA", "I_RANGE_100nA"),
            ("1 uA", "I_RANGE_1uA"),
            ("10 uA", "I_RANGE_10uA"),
            ("100 uA", "I_RANGE_100uA"),
            ("1 mA", "I_RANGE_1mA"),
            ("10 mA", "I_RANGE_10mA"),
            ("100 mA", "I_RANGE_100mA"),
            ("1 A", "I_RANGE_1A"),
            ("Booster", "I_RANGE_BOOSTER"),
            ("Auto", "I_RANGE_AUTO"),
        ]
        for label, key in self.i_range_options:
            self.i_range_combo.addItem(label, key)
        self.i_range_combo.setCurrentText("Auto")
        cv_layout.addRow("I Range:", self.i_range_combo)
        cv_layout.addRow("Scan rate (V/s):", self.scan_rate)
        cv_layout.addRow("N cycles:", self.n_cycles)
        cv_layout.addRow("E start (V):", self.e_start)
        cv_layout.addRow("E vertex 1 (V):", self.e_vertex1)
        cv_layout.addRow("E vertex 2 (V):", self.e_vertex2)
        cv_layout.addRow("E end (V):", self.e_end)
        cv_layout.addRow("Record every dE (V):", self.record_every_de)
        self.param_layout.addWidget(cv_group)

        # --- Electrode configuration dropdown ---
        electrode_group = QtWidgets.QGroupBox("Electrode Configuration")
        electrode_layout = QtWidgets.QFormLayout(electrode_group)
        self.electrode_combo = QtWidgets.QComboBox()
        # Add enum options as (display, value)
        self.electrode_options = [
            ("Standard", KBIO.HW_CNX.STANDARD),
            ("CE to ground", KBIO.HW_CNX.CE_TO_GND),
            ("WE to ground", KBIO.HW_CNX.WE_TO_GND),
            ("High Voltage", KBIO.HW_CNX.HIGH_VOLTAGE),
        ]
        for label, enum_val in self.electrode_options:
            self.electrode_combo.addItem(label, enum_val)
        electrode_layout.addRow("Connection:", self.electrode_combo)
        self.param_layout.addWidget(electrode_group)

        # --- Ewe range for averaging ---
        avg_group = QtWidgets.QGroupBox("Average Iwe Range")
        avg_layout = QtWidgets.QFormLayout(avg_group)
        self.ewe_min = QtWidgets.QDoubleSpinBox(); self.ewe_min.setValue(-0.1); self.ewe_min.setFixedWidth(100)
        self.ewe_max = QtWidgets.QDoubleSpinBox(); self.ewe_max.setValue(0.1); self.ewe_max.setFixedWidth(100)
        avg_layout.addRow("Ewe min (V):", self.ewe_min)
        avg_layout.addRow("Ewe max (V):", self.ewe_max)
        self.param_layout.addWidget(avg_group)

        # --- Start, Pause/Resume, Stop buttons ---
        btn_layout = QtWidgets.QHBoxLayout()
        self.start_btn = QtWidgets.QPushButton("Start Scan")
        self.start_btn.setFixedWidth(120)
        self.start_btn.clicked.connect(self.start_scan)
        btn_layout.addWidget(self.start_btn)

        self.pause_btn = QtWidgets.QPushButton("Pause")
        self.pause_btn.setFixedWidth(120)
        self.pause_btn.clicked.connect(self.pause_scan)
        btn_layout.addWidget(self.pause_btn)

        self.stop_btn = QtWidgets.QPushButton("Stop")
        self.stop_btn.setFixedWidth(120)
        self.stop_btn.clicked.connect(self.stop_scan)
        btn_layout.addWidget(self.stop_btn)

        self.param_layout.addLayout(btn_layout)

        # --- Status ---
        self.status = QtWidgets.QLabel("")
        self.param_layout.addWidget(self.status)

        self.param_layout.addStretch()
        self.main_layout.addWidget(self.param_widget, stretch=0)

        # --- Right: Plots ---
        self.fig, (self.ax_map, self.ax_cv) = plt.subplots(1, 2, figsize=(12, 5))
        self.canvas = FigureCanvas(self.fig)
        self.main_layout.addWidget(self.canvas, stretch=1)
        self.im = None
        self.cv_line, = self.ax_cv.plot([], [], lw=1)
        self.ax_cv.set_xlabel("Ewe (V)")
        self.ax_cv.set_ylabel("Iwe (A)")
        self.ax_cv.set_title("Real-time CV at pixel")

        # --- Data ---
        self.avg_iwe_map = None

        # --- Control flags ---
        self._stop_requested = False
        self._pause_requested = False

        # --- Piezo connection controls ---
        piezo_group = QtWidgets.QGroupBox("NanoLP Connection")
        piezo_layout = QtWidgets.QHBoxLayout(piezo_group)
        self.piezo_status = QtWidgets.QLabel("Disconnected")
        self.piezo_status.setStyleSheet("color: red;")
        self.piezo_connect_btn = QtWidgets.QPushButton("Connect")
        self.piezo_disconnect_btn = QtWidgets.QPushButton("Disconnect")
        self.piezo_disconnect_btn.setEnabled(False)
        piezo_layout.addWidget(self.piezo_status)
        piezo_layout.addWidget(self.piezo_connect_btn)
        piezo_layout.addWidget(self.piezo_disconnect_btn)
        self.param_layout.addWidget(piezo_group)

        # --- XYZ position display ---
        xyz_group = QtWidgets.QGroupBox("Piezo XYZ Position")
        xyz_layout = QtWidgets.QFormLayout(xyz_group)
        self.x_val = QtWidgets.QLabel("N/A")
        self.y_val = QtWidgets.QLabel("N/A")
        self.z_val = QtWidgets.QLabel("N/A")
        xyz_layout.addRow("X (µm):", self.x_val)
        xyz_layout.addRow("Y (µm):", self.y_val)
        xyz_layout.addRow("Z (µm):", self.z_val)
        self.param_layout.addWidget(xyz_group)

        # --- XYZ manual move controls ---
        move_group = QtWidgets.QGroupBox("Manual XYZ Move")
        move_layout = QtWidgets.QGridLayout(move_group)
        self.x_inc = QtWidgets.QDoubleSpinBox(); self.x_inc.setDecimals(3); self.x_inc.setValue(1.0); self.x_inc.setSingleStep(0.1); self.x_inc.setFixedWidth(80)
        self.y_inc = QtWidgets.QDoubleSpinBox(); self.y_inc.setDecimals(3); self.y_inc.setValue(1.0); self.y_inc.setSingleStep(0.1); self.y_inc.setFixedWidth(80)
        self.z_inc = QtWidgets.QDoubleSpinBox(); self.z_inc.setDecimals(3); self.z_inc.setValue(1.0); self.z_inc.setSingleStep(0.1); self.z_inc.setFixedWidth(80)
        move_layout.addWidget(QtWidgets.QLabel("X increment (µm):"), 0, 0)
        move_layout.addWidget(self.x_inc, 0, 1)
        move_layout.addWidget(QtWidgets.QLabel("Y increment (µm):"), 1, 0)
        move_layout.addWidget(self.y_inc, 1, 1)
        move_layout.addWidget(QtWidgets.QLabel("Z increment (µm):"), 2, 0)
        move_layout.addWidget(self.z_inc, 2, 1)

        self.x_minus_btn = QtWidgets.QPushButton("-X"); self.x_minus_btn.setFixedWidth(40)
        self.x_plus_btn = QtWidgets.QPushButton("+X"); self.x_plus_btn.setFixedWidth(40)
        self.y_minus_btn = QtWidgets.QPushButton("-Y"); self.y_minus_btn.setFixedWidth(40)
        self.y_plus_btn = QtWidgets.QPushButton("+Y"); self.y_plus_btn.setFixedWidth(40)
        self.z_minus_btn = QtWidgets.QPushButton("-Z"); self.z_minus_btn.setFixedWidth(40)
        self.z_plus_btn = QtWidgets.QPushButton("+Z"); self.z_plus_btn.setFixedWidth(40)
        move_layout.addWidget(self.x_minus_btn, 0, 2)
        move_layout.addWidget(self.x_plus_btn, 0, 3)
        move_layout.addWidget(self.y_minus_btn, 1, 2)
        move_layout.addWidget(self.y_plus_btn, 1, 3)
        move_layout.addWidget(self.z_minus_btn, 2, 2)
        move_layout.addWidget(self.z_plus_btn, 2, 3)
        self.param_layout.addWidget(move_group)

        # --- Connect movement buttons ---
        self.x_minus_btn.clicked.connect(lambda: self.move_piezo_axis('x', -self.x_inc.value()))
        self.x_plus_btn.clicked.connect(lambda: self.move_piezo_axis('x', self.x_inc.value()))
        self.y_minus_btn.clicked.connect(lambda: self.move_piezo_axis('y', -self.y_inc.value()))
        self.y_plus_btn.clicked.connect(lambda: self.move_piezo_axis('y', self.y_inc.value()))
        self.z_minus_btn.clicked.connect(lambda: self.move_piezo_axis('z', -self.z_inc.value()))
        self.z_plus_btn.clicked.connect(lambda: self.move_piezo_axis('z', self.z_inc.value()))

        # --- Piezo instance ---
        self.piezo = None

        # --- Connect signals ---
        self.piezo_connect_btn.clicked.connect(self.connect_piezo)
        self.piezo_disconnect_btn.clicked.connect(self.disconnect_piezo)

        # --- Timer for updating XYZ ---
        self.xyz_timer = QtCore.QTimer()
        self.xyz_timer.timeout.connect(self.update_xyz_display)
        self.xyz_timer.start(1000)  # update every second

        # --- Output path and directory name controls ---
        output_group = QtWidgets.QGroupBox("Output Settings")
        output_layout = QtWidgets.QFormLayout(output_group)
        self.output_path_edit = QtWidgets.QLineEdit(r"L:\lnet-commun\shared\[99] Transfer\German")
        self.output_browse_btn = QtWidgets.QPushButton("Browse")
        self.dir_name_edit = QtWidgets.QLineEdit()
        self.dir_name_edit.setPlaceholderText("Leave blank for default (cv_scan_YYYYMMDD_HHMMSS)")
        output_path_layout = QtWidgets.QHBoxLayout()
        output_path_layout.addWidget(self.output_path_edit)
        output_path_layout.addWidget(self.output_browse_btn)
        output_layout.addRow("Save path:", output_path_layout)
        output_layout.addRow("Directory name:", self.dir_name_edit)
        self.param_layout.addWidget(output_group)

        self.output_browse_btn.clicked.connect(self.browse_output_path)

        # Additional initialization
        self.cbar = None

    def connect_piezo(self):
        try:
            self.piezo = Madpiezo()
            # Grab handle by device type (8707 = Nano-Drive 20 bit Single Axis)
            handle = self.piezo.grab_handle_by_type(8707)
            if handle == 0 or handle == -1:
                raise Exception("Failed to grab handle for device type 8707")
            self.piezo.handler = handle
            # Try a simple command to verify connection
            x, y, z = self.piezo.get_position()
            self.piezo_status.setText("Connected")
            self.piezo_status.setStyleSheet("color: green;")
            self.piezo_connect_btn.setEnabled(False)
            self.piezo_disconnect_btn.setEnabled(True)
        except Exception as e:
            self.piezo = None
            self.piezo_status.setText("Connection Failed")
            self.piezo_status.setStyleSheet("color: red;")
            self.piezo_connect_btn.setEnabled(True)
            self.piezo_disconnect_btn.setEnabled(False)
            self.status.setText(f"Piezo connection failed: {e}")

    def disconnect_piezo(self):
        if self.piezo is not None:
            try:
                self.piezo.mcl_close()
            except Exception:
                pass
        self.piezo = None
        self.piezo_status.setText("Disconnected")
        self.piezo_status.setStyleSheet("color: red;")
        self.piezo_connect_btn.setEnabled(True)
        self.piezo_disconnect_btn.setEnabled(False)
        self.x_val.setText("N/A")
        self.y_val.setText("N/A")
        self.z_val.setText("N/A")

    def update_xyz_display(self):
        if self.piezo is not None:
            try:
                x, y, z = self.piezo.get_position()
                self.x_val.setText(f"{x:.3f}")
                self.y_val.setText(f"{y:.3f}")
                self.z_val.setText(f"{z:.3f}")
            except Exception:
                self.x_val.setText("Err")
                self.y_val.setText("Err")
                self.z_val.setText("Err")
        else:
            self.x_val.setText("N/A")
            self.y_val.setText("N/A")
            self.z_val.setText("N/A")

    def pause_scan(self):
        if not self._pause_requested:
            self._pause_requested = True
            self.pause_btn.setText("Resume")
            self.status.setText("Paused. Click Resume to continue.")
        else:
            self._pause_requested = False
            self.pause_btn.setText("Pause")
            self.status.setText("Resuming scan...")

    def stop_scan(self):
        self._stop_requested = True
        self.status.setText("Stop requested. Finishing current pixel...")

    def start_scan(self):
        self._stop_requested = False
        self._pause_requested = False
        self.pause_btn.setText("Pause")
        self.status.setText("Initializing scan...")
        QtWidgets.QApplication.processEvents()
        # --- Prepare scan grid ---
        len_x = self.len_x.value()
        len_y = self.len_y.value()
        x1, x2 = self.x1.value(), self.x2.value()
        y1, y2 = self.y1.value(), self.y2.value()
        wait_time = self.wait_time.value()

        # Get current piezo position as scan origin
        try:
            x0, y0, _ = self.piezo.get_position()
        except Exception as e:
            self.status.setText(f"Could not read piezo position: {e}")
            return

        # Build scan grid relative to current position (serpentine/raster pattern)
        x_lin = np.linspace(x0 + x1, x0 + x2, len_x)
        y_lin = np.linspace(y0 + y1, y0 + y2, len_y)
        x_pattern = np.zeros((len_y, len_x))
        y_pattern = np.zeros((len_y, len_x))
        for i, y in enumerate(y_lin):
            if i % 2 == 0:
                x_pattern[i, :] = x_lin
            else:
                x_pattern[i, :] = x_lin[::-1]
            y_pattern[i, :] = y

        scan_shape = x_pattern.shape

        # --- Prepare output directory ---
        base_path = self.output_path_edit.text().strip()
        custom_dir = self.dir_name_edit.text().strip()
        if not custom_dir:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            dir_name = f"cv_scan_{timestamp}"
        else:
            dir_name = custom_dir
        out_dir = os.path.join(base_path, dir_name)
        os.makedirs(out_dir, exist_ok=True)

        # --- Prepare CV parameters ---
        scan_rate = self.scan_rate.value()
        n_cycles = self.n_cycles.value()
        e_start = self.e_start.value()
        e_vertex1 = self.e_vertex1.value()
        e_vertex2 = self.e_vertex2.value()
        e_end = self.e_end.value()
        record_every_de = self.record_every_de.value()
        i_range_key = self.i_range_combo.currentData()

        ewe_min = self.ewe_min.value()
        ewe_max = self.ewe_max.value()

        # --- Piezo and EC-Lab setup ---
        if self.piezo is None:
            self.status.setText("Piezo not connected!")
            return
        # --- EC-Lab setup (minimal, adjust as needed) ---
        verbosity = 1
        address = "192.109.209.128"
        channel = 1
        binary_path = "C:/EC-Lab Development Package/lib"
        if c_is_64b:
            DLL_file = "EClib64.dll"
        else:
            DLL_file = "EClib.dll"
        DLL_path = f"{binary_path}{os.sep}{DLL_file}"
        api = KBIO_api(DLL_path)
        id_, device_info = api.Connect(address)
        board_type = api.GetChannelBoardType(id_, channel)
        cv3_tech_file = "cv.ecc"
        cv4_tech_file = "cv4.ecc"
        cv5_tech_file = "cv5.ecc"
        match board_type:
            case KBIO.BOARD_TYPE.ESSENTIAL.value:
                tech_file = cv3_tech_file
            case KBIO.BOARD_TYPE.PREMIUM.value:
                tech_file = cv4_tech_file
            case KBIO.BOARD_TYPE.DIGICORE.value:
                tech_file = cv5_tech_file
            case _:
                self.status.setText("Board type detection failed")
                return

        # --- CV parameter objects ---
        CV_parms = {
            "vs_initial": ECC_parm("vs_initial", bool),
            "Voltage_step": ECC_parm("Voltage_step", float),
            "Scan_Rate": ECC_parm("Scan_Rate", float),
            "Scan_number": ECC_parm("Scan_number", int),
            "Record_every_dE": ECC_parm("Record_every_dE", float),
            "Average_over_dE": ECC_parm("Average_over_dE", bool),
            "N_Cycles": ECC_parm("N_Cycles", int),
            "Begin_measuring_I": ECC_parm("Begin_measuring_I", float),
            "End_measuring_I": ECC_parm("End_measuring_I", float),
            "I_range": ECC_parm("I_Range", int),  
        }
        # Example for a simple CV (adjust as needed)
        vs_initial = [False, False, False, False, False]
        Voltage_step = [e_start, e_vertex1, e_vertex2, e_start, e_end]
        Scan_Rate = [scan_rate]*5
        Scan_number = 2
        Record_every_dE = record_every_de
        Average_over_dE = False
        N_Cycles = n_cycles
        Begin_measuring_I = 0
        End_measuring_I = 1
        i_range = "I_RANGE_1nA"

        p_vs_initial = [make_ecc_parm(api, CV_parms["vs_initial"], val, idx) for idx, val in enumerate(vs_initial)]
        p_Voltage_step = [make_ecc_parm(api, CV_parms["Voltage_step"], val, idx) for idx, val in enumerate(Voltage_step)]
        p_Scan_Rate = [make_ecc_parm(api, CV_parms["Scan_Rate"], val, idx) for idx, val in enumerate(Scan_Rate)]
        p_Scan_number = make_ecc_parm(api, CV_parms["Scan_number"], Scan_number)
        p_Record_every_dE = make_ecc_parm(api, CV_parms["Record_every_dE"], Record_every_dE)
        p_Average_over_dE = make_ecc_parm(api, CV_parms["Average_over_dE"], Average_over_dE)
        p_N_Cycles = make_ecc_parm(api, CV_parms["N_Cycles"], N_Cycles)
        p_Begin_measuring_I = make_ecc_parm(api, CV_parms["Begin_measuring_I"], Begin_measuring_I)
        p_End_measuring_I = make_ecc_parm(api, CV_parms["End_measuring_I"], End_measuring_I)
        p_I_range = make_ecc_parm(api, CV_parms["I_range"], KBIO.I_RANGE[i_range_key].value)
        ecc_parms = make_ecc_parms(
            api,
            *p_vs_initial,
            *p_Voltage_step,
            *p_Scan_Rate,
            p_Scan_number,
            p_Record_every_dE,
            p_Average_over_dE,
            p_N_Cycles,
            p_Begin_measuring_I,
            p_End_measuring_I,
            p_I_range
        )

        # --- Prepare result map ---
        self.avg_iwe_map = np.zeros(scan_shape)

        # Remove previous colorbar if it exists (do this BEFORE clearing ax_map)
        if hasattr(self, 'cbar') and self.cbar is not None:
            self.cbar.remove()
            self.cbar = None

        self.ax_map.clear()
        self.im = self.ax_map.imshow(self.avg_iwe_map, origin='lower', extent=[x1, x2, y1, y2], aspect='auto')
        self.cbar = self.fig.colorbar(self.im, ax=self.ax_map, label="Avg Iwe (A)")
        self.ax_map.set_title("CV Point to Point Scan")
        self.ax_cv.clear()
        self.ax_cv.set_xlabel("Ewe (V)")
        self.ax_cv.set_ylabel("Iwe (A)")
        self.ax_cv.set_title("Real-time CV at pixel")
        self.cv_line, = self.ax_cv.plot([], [], lw=1)
        self.canvas.draw()

        # --- Scan loop ---
        for index in np.ndindex(scan_shape):
            # --- Stop logic ---
            if self._stop_requested:
                self.status.setText("Scan stopped by user.")
                break

            # --- Pause logic ---
            while self._pause_requested:
                QtWidgets.QApplication.processEvents()
                time.sleep(0.1)
                if self._stop_requested:
                    self.status.setText("Scan stopped by user.")
                    return

            x, y = x_pattern[index], y_pattern[index]
            self.status.setText(f"Moving to pixel {index} at (x={x:.2f}, y={y:.2f})")
            QtWidgets.QApplication.processEvents()
            self.piezo.goxy(x, y)
            time.sleep(wait_time)
            out_csv = os.path.join(out_dir, f"pixel_{index[0]}_{index[1]}.csv")
            self.status.setText(f"Running CV at pixel {index}")
            QtWidgets.QApplication.processEvents()

            # --- Run CV and plot real-time ---
            electrode_enum = self.electrode_combo.currentData()
            api.SetHardwareConf(id_, channel, electrode_enum.value, KBIO.HW_MODE.GROUNDED.value)
            self.status.setText(f"Electrode connection set to {self.electrode_combo.currentText()}")
            api.LoadTechnique(id_, channel, tech_file, ecc_parms, first=True, last=True, display=(verbosity > 1))
            api.StartChannel(id_, channel)
            ewe_list, iwe_list = [], []
            with open(out_csv, "w") as csvfile:
                csvfile.write("t (s),Ewe (V),Iwe (A),Cycle (N)\n")
                while True:
                    data = api.GetData(id_, channel)
                    status, tech_name = get_info_data(api, data)
                    for output in get_experiment_data(api, data, tech_name, board_type):
                        if len(output) != 5:
                            continue
                        t_high_raw, t_low_raw, i_raw, ewe_raw, cycle_raw = output
                        t_numeric = (int(t_high_raw, 16) << 16) | int(t_low_raw, 16)
                        t = api.ConvertTimeChannelNumericIntoSeconds([t_numeric], 1.0, board_type)
                        Iwe = api.ConvertChannelNumericIntoSingle(int(i_raw, 16), board_type)
                        Ewe = api.ConvertChannelNumericIntoSingle(int(ewe_raw, 16), board_type)
                        cycle = int(cycle_raw, 16)
                        csvfile.write(f"{t},{Ewe},{Iwe},{cycle}\n")
                        ewe_list.append(Ewe)
                        iwe_list.append(Iwe)
                    # --- Update real-time CV plot ---
                    if ewe_list and iwe_list:
                        self.cv_line.set_data(ewe_list, iwe_list)
                        self.ax_cv.relim()
                        self.ax_cv.autoscale_view()
                        self.canvas.draw()
                        QtWidgets.QApplication.processEvents()
                    if status == "STOP":
                        break
                    time.sleep(0.05)

            # --- Analyze and update pixel map ---
            arr = np.genfromtxt(out_csv, delimiter=',', skip_header=1)
            if arr.ndim == 1:
                arr = arr[None, :]
            mask = (arr[:,1] >= ewe_min) & (arr[:,1] <= ewe_max)
            avg_iwe = np.mean(arr[mask,2]) if np.any(mask) else np.nan
            self.avg_iwe_map[index] = avg_iwe
            self.im.set_data(self.avg_iwe_map)
            self.im.autoscale()
            self.canvas.draw()
            self.status.setText(f"Pixel {index} done. Avg Iwe: {avg_iwe:.3e} A")
            QtWidgets.QApplication.processEvents()

        api.Disconnect(id_)
        if self._stop_requested:
            self.status.setText("Scan stopped by user.")
        else:
            self.status.setText(f"Scan complete. Data saved in {out_dir}")

    # Add this method to your class:
    def move_piezo_axis(self, axis, delta):
        if self.piezo is None:
            self.status.setText("Piezo not connected!")
            return
        try:
            x, y, z = self.piezo.get_position()
            if axis == 'x':
                self.piezo.goxy(x + delta, y)
            elif axis == 'y':
                self.piezo.goxy(x, y + delta)
            elif axis == 'z':
                self.piezo.goz(z + delta)
            self.status.setText(f"Moved {axis.upper()} by {delta:+.3f}")
        except Exception as e:
            self.status.setText(f"Move error: {e}")

    def browse_output_path(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Output Directory", self.output_path_edit.text())
        if path:
            self.output_path_edit.setText(path)

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    gui = CVScanGUI()
    gui.show()
    sys.exit(app.exec_())