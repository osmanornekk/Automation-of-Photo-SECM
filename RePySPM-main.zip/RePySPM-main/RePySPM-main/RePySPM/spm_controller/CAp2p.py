import sys
import os
sys.path.insert(0, r"D:\Downloads\RePySPM-main\RePySPM-main\RePySPM\spm_controller\EC-Lab Development Package\Examples\Python")

import time
import numpy as np
from datetime import datetime
from PyQt5 import QtWidgets, QtCore
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

from mcl_piezo_lib import Madpiezo
import nifpga
from kbio.c_utils import c_is_64b
from kbio.kbio_api import KBIO_api
from kbio.kbio_tech import ECC_parm, make_ecc_parm, make_ecc_parms
from kbio.kbio_tech import get_experiment_data, get_info_data
import kbio.kbio_types as KBIO

from dataclasses import dataclass

@dataclass
class ca_step:
    voltage: float
    duration: float
    vs_init: bool = False

# Example steps (edit as needed)
steps = [
    ca_step(0.2, 1),
    ca_step(0, 1, True),

]

repeat_count = 0
record_dt = 0.0001
record_dI = 0.00000000000010
i_range = "I_RANGE_AUTO"

CA_parms = {
    "voltage_step": ECC_parm("Voltage_step", float),
    "duration_step": ECC_parm("Duration_step", float),
    "vs_init": ECC_parm("vs_initial", bool),
    "nb_steps": ECC_parm("Step_number", int),
    "record_dt": ECC_parm("Record_every_dT", float),
    "record_dI": ECC_parm("Record_every_dI", float),
    "repeat": ECC_parm("N_Cycles", int),
    "I_range": ECC_parm("I_Range", int),
}

class CAScanGUI(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CA Point to Point Scanning")
        self.resize(1800, 900)

        # --- Layouts ---
        self.main_layout = QtWidgets.QHBoxLayout(self)
        self.setLayout(self.main_layout)
        self.param_widget = QtWidgets.QWidget()
        self.param_layout = QtWidgets.QVBoxLayout(self.param_widget)

        # --- Scan parameters ---
        scan_group = QtWidgets.QGroupBox("Scan Parameters")
        scan_layout = QtWidgets.QFormLayout(scan_group)
        self.len_x = QtWidgets.QSpinBox(); self.len_x.setValue(5); self.len_x.setMaximum(1024)
        self.len_y = QtWidgets.QSpinBox(); self.len_y.setValue(5); self.len_y.setMaximum(1024)
        self.x1 = QtWidgets.QDoubleSpinBox(); self.x1.setValue(0.0)
        self.x2 = QtWidgets.QDoubleSpinBox(); self.x2.setValue(40.0)
        self.y1 = QtWidgets.QDoubleSpinBox(); self.y1.setValue(0.0)
        self.y2 = QtWidgets.QDoubleSpinBox(); self.y2.setValue(40.0)
        self.wait_time = QtWidgets.QDoubleSpinBox(); self.wait_time.setValue(1.0)
        scan_layout.addRow("Pixels X:", self.len_x)
        scan_layout.addRow("Pixels Y:", self.len_y)
        scan_layout.addRow("X1 (µm):", self.x1)
        scan_layout.addRow("X2 (µm):", self.x2)
        scan_layout.addRow("Y1 (µm):", self.y1)
        scan_layout.addRow("Y2 (µm):", self.y2)
        scan_layout.addRow("Wait after move (s):", self.wait_time)
        self.param_layout.addWidget(scan_group)

        # --- CA parameters (removed CA Potential, Duration, I Range) ---
        ca_group = QtWidgets.QGroupBox("CA Acquisition Parameters")
        ca_layout = QtWidgets.QFormLayout(ca_group)
        self.repeat_count_spin = QtWidgets.QSpinBox()
        self.repeat_count_spin.setMinimum(1)
        self.repeat_count_spin.setValue(1)
        self.record_dt_spin = QtWidgets.QDoubleSpinBox()
        self.record_dt_spin.setDecimals(6)
        self.record_dt_spin.setSingleStep(0.001)
        self.record_dt_spin.setValue(0.01)
        self.record_dI_spin = QtWidgets.QDoubleSpinBox()
        self.record_dI_spin.setDecimals(12)
        self.record_dI_spin.setSingleStep(1e-12)
        self.record_dI_spin.setValue(0.0)
        # Allow scientific notation for record_dI
        self.record_dI_edit = QtWidgets.QLineEdit("0.0")
        self.record_dI_edit.setPlaceholderText("e.g. 1e-12")
        self.record_dI_edit.setText(str(self.record_dI_spin.value()))
        ca_layout.addRow("Repeat count:", self.repeat_count_spin)
        ca_layout.addRow("Record every dT (s):", self.record_dt_spin)
        ca_layout.addRow("Record every dI (A):", self.record_dI_edit)
        self.param_layout.addWidget(ca_group)

        # --- Output path ---
        output_group = QtWidgets.QGroupBox("Output Settings")
        output_layout = QtWidgets.QFormLayout(output_group)
        self.output_path_edit = QtWidgets.QLineEdit(r"L:\lnet-commun\shared\[99] Transfer\German")
        self.output_browse_btn = QtWidgets.QPushButton("Browse")
        self.dir_name_edit = QtWidgets.QLineEdit()
        self.dir_name_edit.setPlaceholderText("Leave blank for default (ca_scan_YYYYMMDD_HHMMSS)")
        output_path_layout = QtWidgets.QHBoxLayout()
        output_path_layout.addWidget(self.output_path_edit)
        output_path_layout.addWidget(self.output_browse_btn)
        output_layout.addRow("Save path:", output_path_layout)
        output_layout.addRow("Directory name:", self.dir_name_edit)
        self.param_layout.addWidget(output_group)
        self.output_browse_btn.clicked.connect(self.browse_output_path)

        # --- CA steps table ---
        steps_group = QtWidgets.QGroupBox("CA Steps")
        steps_layout = QtWidgets.QVBoxLayout(steps_group)
        self.steps_table = QtWidgets.QTableWidget(0, 3)
        self.steps_table.setHorizontalHeaderLabels(["Voltage (V)", "Duration (s)", "vs_init"])
        self.steps_table.horizontalHeader().setSectionResizeMode(QtWidgets.QHeaderView.Stretch)
        steps_layout.addWidget(self.steps_table)

        btn_steps_layout = QtWidgets.QHBoxLayout()
        self.add_step_btn = QtWidgets.QPushButton("Add Step")
        self.remove_step_btn = QtWidgets.QPushButton("Remove Step")
        btn_steps_layout.addWidget(self.add_step_btn)
        btn_steps_layout.addWidget(self.remove_step_btn)
        steps_layout.addLayout(btn_steps_layout)
        self.param_layout.addWidget(steps_group)

        self.add_step_btn.clicked.connect(self.add_step_row)
        self.remove_step_btn.clicked.connect(self.remove_step_row)

        # Initialize with default steps
        self.set_steps_table([
            ca_step(0.2, 1),
            ca_step(0, 1, True),
        ])

        # --- Start/Stop buttons ---
        btn_layout = QtWidgets.QHBoxLayout()
        self.start_btn = QtWidgets.QPushButton("Start Scan")
        self.start_btn.clicked.connect(self.start_scan)
        btn_layout.addWidget(self.start_btn)
        self.stop_btn = QtWidgets.QPushButton("Stop")
        self.stop_btn.clicked.connect(self.stop_scan)
        btn_layout.addWidget(self.stop_btn)
        self.param_layout.addLayout(btn_layout)

        # --- Status ---
        self.status = QtWidgets.QLabel("")
        self.param_layout.addWidget(self.status)
        self.param_layout.addStretch()
        self.main_layout.addWidget(self.param_widget, stretch=0)

        # --- Right: Plots ---
        self.fig, (self.ax_map, self.ax_fpga, self.ax_eclab) = plt.subplots(1, 3, figsize=(18, 5))
        self.canvas = FigureCanvas(self.fig)
        self.main_layout.addWidget(self.canvas, stretch=1)
        self.im = None
        self.fpga_line, = self.ax_fpga.plot([], [], lw=1)
        self.eclab_line, = self.ax_eclab.plot([], [], lw=1)
        self.ax_map.set_title("CA Point to Point Scan (Avg I)")
        self.ax_fpga.set_title("FPGA CA trace at pixel")
        self.ax_fpga.set_xlabel("Time (s)")
        self.ax_fpga.set_ylabel("FPGA current (A)")
        self.ax_eclab.set_title("EC-Lab CA trace at pixel")
        self.ax_eclab.set_xlabel("Time (s)")
        self.ax_eclab.set_ylabel("Iwe (A)")
        self.cbar = None

        # --- Piezo ---
        self.piezo = None
        self._stop_requested = False

        # --- I Range Combo Box ---
        i_range_group = QtWidgets.QGroupBox("Current Range")
        i_range_layout = QtWidgets.QFormLayout(i_range_group)
        self.i_range_combo = QtWidgets.QComboBox()
        # Populate with available ranges from KBIO.I_RANGE
        self.i_range_keys = [k for k in KBIO.I_RANGE.__members__.keys()]
        self.i_range_combo.addItems(self.i_range_keys)
        # Set default selection
        if "I_RANGE_AUTO" in self.i_range_keys:
            self.i_range_combo.setCurrentText("I_RANGE_AUTO")
        i_range_layout.addRow("I Range:", self.i_range_combo)
        self.param_layout.addWidget(i_range_group)

        # --- Piezo connection controls ---
        piezo_group = QtWidgets.QGroupBox("NanoLP Connection")
        piezo_layout = QtWidgets.QHBoxLayout(piezo_group)
        self.piezo_status = QtWidgets.QLabel("Disconnected")
        self.piezo_status.setStyleSheet("color: red;")
        self.piezo_connect_btn = QtWidgets.QPushButton("Connect Piezo")

        self.piezo_disconnect_btn = QtWidgets.QPushButton("Disconnect")
        self.piezo_disconnect_btn.setEnabled(False)

        piezo_layout.addWidget(self.piezo_status)
        piezo_layout.addWidget(self.piezo_connect_btn)
        self.param_layout.addWidget(piezo_group)

        piezo_layout.addWidget(self.piezo_disconnect_btn)

        self.piezo_connect_btn.clicked.connect(self.connect_piezo)
        self.piezo_disconnect_btn.clicked.connect(self.disconnect_piezo)

    def browse_output_path(self):
        path = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Output Directory", self.output_path_edit.text())
        if path:
            self.output_path_edit.setText(path)

    def stop_scan(self):
        self._stop_requested = True
        self.status.setText("Stop requested. Finishing current pixel...")

    def start_scan(self):
        self._stop_requested = False
        self.status.setText("Initializing scan...")
        QtWidgets.QApplication.processEvents()

        # --- Piezo and FPGA setup ---
        if self.piezo is None:
            self.status.setText("Piezo not connected!")
            return
        try:
            x0, y0, _ = self.piezo.get_position()
        except Exception as e:
            self.status.setText(f"Could not read piezo position: {e}")
            return

        project_path = r"C:\Users\adminlnet\OpenSPM-source"
        bitfile_folder = os.path.join(project_path, "FPGA Bitfiles")
        bitfile_path = os.path.join(bitfile_folder, "lbniAFMController_usbRIO_controllerFPGA_testboard.lvbitx")
        resource_name = "RIO0"
        try:
            fpga_session = nifpga.Session(bitfile_path, resource_name)
        except Exception as e:
            self.status.setText(f"Could not connect to FPGA: {e}")
            return

        # --- EC-Lab setup (minimal, adjust as needed) ---
        verbosity = 1
        address = "192.109.209.128"
        channel = 1
        binary_path = "C:/EC-Lab Development Package/lib"
        if c_is_64b:
            DLL_file = "EClib64.dll"
        else:
            DLL_file = "EClib.dll"
        DLL_path = f"{binary_path}{os.sep}{DLL_file}"
        api = KBIO_api(DLL_path)
        id_, device_info = api.Connect(address)
        board_type = api.GetChannelBoardType(id_, channel)
        ca3_tech_file = "ca.ecc"
        ca4_tech_file = "ca4.ecc"
        ca5_tech_file = "ca5.ecc"
        match board_type:
            case KBIO.BOARD_TYPE.ESSENTIAL.value:
                tech_file = ca3_tech_file
            case KBIO.BOARD_TYPE.PREMIUM.value:
                tech_file = ca4_tech_file
            case KBIO.BOARD_TYPE.DIGICORE.value:
                tech_file = ca5_tech_file
            case _:
                self.status.setText("Board type detection failed")
                return

        # --- Prepare scan grid ---
        len_x = self.len_x.value()
        len_y = self.len_y.value()
        x1, x2 = self.x1.value(), self.x2.value()
        y1, y2 = self.y1.value(), self.y2.value()
        wait_time = self.wait_time.value()

        # --- Get CA acquisition parameters from GUI ---
        repeat_count = self.repeat_count_spin.value()
        record_dt = self.record_dt_spin.value()
        try:
            record_dI = float(self.record_dI_edit.text().replace('E', 'e'))
        except Exception:
            record_dI = 0.0

        # --- Use steps from table ---
        steps = self.get_steps_from_table()

        # --- Prepare CA parameters for a single step ---
        p_voltage_step = make_ecc_parm(api, CA_parms["voltage_step"], 0.2, 0)
        p_duration_step = make_ecc_parm(api, CA_parms["duration_step"], 2.0, 0)
        p_vs_init = make_ecc_parm(api, CA_parms["vs_init"], False, 0)
        p_nb_steps = make_ecc_parm(api, CA_parms["nb_steps"], 0)
        p_record_dt = make_ecc_parm(api, CA_parms["record_dt"], 0.01)
        p_record_dI = make_ecc_parm(api, CA_parms["record_dI"], 0.0)
        p_repeat = make_ecc_parm(api, CA_parms["repeat"], 1)
        i_range_key = self.i_range_combo.currentText()
        p_I_range = make_ecc_parm(api, CA_parms["I_range"], KBIO.I_RANGE[i_range_key].value)

        ca_parms = make_ecc_parms(
            api,
            p_voltage_step,
            p_duration_step,
            p_vs_init,
            p_nb_steps,
            p_record_dt,
            p_record_dI,
            p_I_range,
            p_repeat
        )
        api.LoadTechnique(id_, channel, tech_file, ca_parms, first=True, last=True, display=False)
        api.StartChannel(id_, channel)

        # --- Prepare scan grid ---
        x_lin = np.linspace(x0 + x1, x0 + x2, len_x)
        y_lin = np.linspace(y0 + y1, y0 + y2, len_y)
        x_pattern = np.zeros((len_y, len_x))
        y_pattern = np.zeros((len_y, len_x))
        for i, y in enumerate(y_lin):
            if i % 2 == 0:
                x_pattern[i, :] = x_lin
            else:
                x_pattern[i, :] = x_lin[::-1]
            y_pattern[i, :] = y
        scan_shape = x_pattern.shape

        # --- Prepare output directory ---
        base_path = self.output_path_edit.text().strip()
        custom_dir = self.dir_name_edit.text().strip()
        if not custom_dir:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            dir_name = f"ca_scan_{timestamp}"
        else:
            dir_name = custom_dir
        out_dir = os.path.join(base_path, dir_name)
        os.makedirs(out_dir, exist_ok=True)

        # --- Prepare result map ---
        avg_fpga_map = np.zeros(scan_shape)
        if self.cbar is not None:
            self.cbar.remove()
            self.cbar = None
        self.ax_map.clear()
        self.im = self.ax_map.imshow(avg_fpga_map, origin='lower', extent=[x1, x2, y1, y2], aspect='auto')
        self.cbar = self.fig.colorbar(self.im, ax=self.ax_map, label="FPGA avg current (A)")
        self.ax_map.set_title("CA Point to Point Scan")
        self.ax_fpga.clear()
        self.fpga_line, = self.ax_fpga.plot([], [], lw=1)
        self.ax_fpga.set_title("FPGA CA trace at pixel")
        self.ax_fpga.set_xlabel("Time (s)")
        self.ax_fpga.set_ylabel("FPGA current (A)")
        self.ax_eclab.clear()
        self.eclab_line, = self.ax_eclab.plot([], [], lw=1)
        self.ax_eclab.set_title("EC-Lab CA trace at pixel")
        self.ax_eclab.set_xlabel("Time (s)")
        self.ax_eclab.set_ylabel("Iwe (A)")
        self.canvas.draw()

        # --- Scan loop ---
        for index in np.ndindex(scan_shape):
            if self._stop_requested:
                self.status.setText("Scan stopped by user.")
                break

            x, y = x_pattern[index], y_pattern[index]
            self.status.setText(f"Moving to pixel {index} at (x={x:.2f}, y={y:.2f})")
            QtWidgets.QApplication.processEvents()
            self.piezo.goxy(x, y)
            time.sleep(wait_time)
            out_csv_fpga = os.path.join(out_dir, f"pixel_{index[0]}_{index[1]}_fpga.csv")
            out_csv_ca = os.path.join(out_dir, f"pixel_{index[0]}_{index[1]}_ec.csv")
            self.status.setText(f"Running CA at pixel {index}")
            QtWidgets.QApplication.processEvents()

            # --- Build CA parameters for all steps ---
            p_steps = []
            for idx, step in enumerate(steps):
                p_steps.append(make_ecc_parm(api, CA_parms["voltage_step"], step.voltage, idx))
                p_steps.append(make_ecc_parm(api, CA_parms["duration_step"], step.duration, idx))
                p_steps.append(make_ecc_parm(api, CA_parms["vs_init"], step.vs_init, idx))
            p_nb_steps = make_ecc_parm(api, CA_parms["nb_steps"], len(steps) - 1)
            p_record_dt = make_ecc_parm(api, CA_parms["record_dt"], record_dt)
            p_record_dI = make_ecc_parm(api, CA_parms["record_dI"], record_dI)
            p_repeat = make_ecc_parm(api, CA_parms["repeat"], repeat_count)
            i_range_key = self.i_range_combo.currentText()
            p_I_range = make_ecc_parm(api, CA_parms["I_range"], KBIO.I_RANGE[i_range_key].value)

            ca_parms = make_ecc_parms(
                api,
                *p_steps,
                p_nb_steps,
                p_record_dt,
                p_record_dI,
                p_I_range,
                p_repeat
            )

            # --- Load and start technique for this pixel ---
            api.LoadTechnique(id_, channel, tech_file, ca_parms, first=True, last=True, display=False)
            api.StartChannel(id_, channel)

            # --- Data acquisition loop: wait for technique to finish ---
            t_list, v_list = [], []
            t_ca, ewe_ca, i_ca, cycle_ca = [], [], [], []
            plot_every = 100
            sample_count = 0
            print("> Reading data ", end="", flush=True)
            while True:
                t_now = time.time()
                value = fpga_session.registers['aio.s.slowVertical'].read() / 32768
                t_list.append(t_now)
                v_list.append(value)
                sample_count += 1

                data = api.GetData(id_, channel)
                status, tech_name = get_info_data(api, data)
                for output in get_experiment_data(api, data, tech_name, board_type):
                    if len(output) != 5:
                        continue
                    t_high_raw, t_low_raw, ewe_raw, i_raw, cycle_raw = output
                    t_numeric = (int(t_high_raw, 16) << 16) | int(t_low_raw, 16)
                    t_sec = api.ConvertTimeChannelNumericIntoSeconds([t_numeric], 1.0, board_type)
                    Ewe = api.ConvertChannelNumericIntoSingle(int(ewe_raw, 16), board_type)
                    Iwe = api.ConvertChannelNumericIntoSingle(int(i_raw, 16), board_type)
                    cycle = int(cycle_raw, 16)
                    t_ca.append(t_sec)
                    ewe_ca.append(Ewe)
                    i_ca.append(Iwe)
                    cycle_ca.append(cycle)

                if sample_count % plot_every == 0:
                    self.fpga_line.set_data(t_list, v_list)
                    self.ax_fpga.relim()
                    self.ax_fpga.autoscale_view()
                    self.canvas.draw()
                    QtWidgets.QApplication.processEvents()

                if status == "STOP":
                    break

            # Final plot update after acquisition
            self.fpga_line.set_data(t_list, v_list)
            self.ax_fpga.relim()
            self.ax_fpga.autoscale_view()
            self.canvas.draw()
            QtWidgets.QApplication.processEvents()

            # --- Save traces and update map ---
            np.savetxt(out_csv_fpga, np.column_stack([t_list, v_list]), delimiter=',', header="t (s),FPGA current (A)", comments='')
            np.savetxt(out_csv_ca, np.column_stack([t_ca, ewe_ca, i_ca, cycle_ca]), delimiter=',', header="t (s),Ewe (V),Iwe (A),Cycle (N)", comments='')
            avg_value = np.mean(v_list)
            avg_fpga_map[index] = avg_value
            self.im.set_data(avg_fpga_map)
            self.im.autoscale()

            # --- Plot EC-Lab I vs time after pixel is finished ---
            self.ax_eclab.clear()
            if len(t_ca) > 0 and len(i_ca) > 0:
                self.ax_eclab.plot(t_ca, i_ca, label="EC-Lab I vs t", color="tab:blue")
                self.ax_eclab.set_title("CA trace at pixel (EC-Lab)")
                self.ax_eclab.set_xlabel("Time (s)")
                self.ax_eclab.set_ylabel("Iwe (A)")
                self.ax_eclab.legend()
            else:
                self.ax_eclab.set_title("No EC-Lab data")
            self.canvas.draw()

            self.status.setText(f"Pixel {index} done. Avg FPGA current: {avg_value:.3e} A")
            QtWidgets.QApplication.processEvents()

        self.status.setText(f"Scan complete. Data saved.")

    def set_steps_table(self, steps):
        self.steps_table.setRowCount(0)
        for step in steps:
            self.add_step_row(step)

    def add_step_row(self, step=None):
        row = self.steps_table.rowCount()
        self.steps_table.insertRow(row)
        voltage_item = QtWidgets.QTableWidgetItem(str(step.voltage if step else 0.0))
        duration_item = QtWidgets.QTableWidgetItem(str(step.duration if step else 1.0))
        vs_init_item = QtWidgets.QTableWidgetItem()
        vs_init_item.setFlags(vs_init_item.flags() | QtCore.Qt.ItemIsUserCheckable)
        vs_init_item.setCheckState(QtCore.Qt.Checked if (step.vs_init if step else False) else QtCore.Qt.Unchecked)
        self.steps_table.setItem(row, 0, voltage_item)
        self.steps_table.setItem(row, 1, duration_item)
        self.steps_table.setItem(row, 2, vs_init_item)

    def remove_step_row(self):
        row = self.steps_table.rowCount()
        if row > 0:
            self.steps_table.removeRow(row - 1)

    def get_steps_from_table(self):
        steps = []
        for row in range(self.steps_table.rowCount()):
            voltage = float(self.steps_table.item(row, 0).text())
            duration = float(self.steps_table.item(row, 1).text())
            vs_init = self.steps_table.item(row, 2).checkState() == QtCore.Qt.Checked
            steps.append(ca_step(voltage, duration, vs_init))
        return steps
    """
    def connect_piezo(self):
        try:
            self.piezo = Madpiezo()
            # Grab handle by device type (8707 = Nano-Drive 20 bit Three Axis)
            handle = self.piezo.grab_handle_by_type(8707)
            if handle == 0 or handle == -1:
                raise Exception("Failed to grab handle for device type 8707")
            self.piezo.handler = handle
            # Try a simple command to verify connection
            x, y, z = self.piezo.get_position()
            self.piezo_status.setText("Connected")
            self.piezo_status.setStyleSheet("color: green;")
        except Exception as e:
            self.piezo = None
            self.piezo_status.setText("Connection Failed")
            self.piezo_status.setStyleSheet("color: red;")
    """

    def connect_piezo(self):
        try:
            self.piezo = Madpiezo()
            # Grab handle by device type (8707 = Nano-Drive 20 bit Single Axis)
            handle = self.piezo.grab_handle_by_type(8707)
            if handle == 0 or handle == -1:
                raise Exception("Failed to grab handle for device type 8707")
            self.piezo.handler = handle
            # Try a simple command to verify connection
            x, y, z = self.piezo.get_position()
            self.piezo_status.setText("Connected")
            self.piezo_status.setStyleSheet("color: green;")
            self.piezo_connect_btn.setEnabled(False)
            self.piezo_disconnect_btn.setEnabled(True)
        except Exception as e:
            self.piezo = None
            self.piezo_status.setText("Connection Failed")
            self.piezo_status.setStyleSheet("color: red;")
            self.piezo_connect_btn.setEnabled(True)
            self.piezo_disconnect_btn.setEnabled(False)
            self.status.setText(f"Piezo connection failed: {e}")

    def disconnect_piezo(self):
        if self.piezo is not None:
            try:
                self.piezo.mcl_close()
            except Exception:
                pass
        self.piezo = None
        self.piezo_status.setText("Disconnected")
        self.piezo_status.setStyleSheet("color: red;")
        self.piezo_connect_btn.setEnabled(True)
        self.piezo_disconnect_btn.setEnabled(False)
        #self.x_val.setText("N/A")
        #self.y_val.setText("N/A")
        #self.z_val.setText("N/A")
if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    gui = CAScanGUI()
    gui.show()
    sys.exit(app.exec_())