from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(1600, 1000)

        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralLayout = QtWidgets.QHBoxLayout(self.centralwidget)
        self.centralLayout.setContentsMargins(10, 10, 10, 10)

        # ---------------------- SOL PANEL ----------------------
        self.leftPanel = QtWidgets.QWidget(self.centralwidget)
        self.leftPanel.setMinimumWidth(650)
        self.leftLayout = QtWidgets.QVBoxLayout(self.leftPanel)

        # === ÜST BÖLÜM ===
        self.topSection = QtWidgets.QWidget()
        self.topLayout = QtWidgets.QHBoxLayout(self.topSection)

        self.textBrowser = QtWidgets.QTextBrowser()
        self.textBrowser.setMinimumHeight(150)
        self.textBrowser.setHtml("""
        <p align=\"justify\"><span style=\"font-size:12pt; font-weight:600;\">USER MANUAL</span></p>
        <p align=\"justify\">Welcome to LNET. Please follow the steps below carefully to initialize and operate the application:</p>
        <ol>
            <li><b>Close all open LabVIEW files</b> (ensure this is done for <i>both</i> LabVIEW versions).</li>
            <li><b>Launch LabVIEW 2022 manually.</b></li>
            <li>Open the <b>OpenSPM Project</b> located in the <b>C module</b> (not the D module).</li>
            <li>Run <code>menu.vi</code>.</li>
            <li>From within <code>menu.vi</code>, open both the <b>LV Bridge</b> and <b>Z Scan</b> modules.</li>
            <li>Finally, run the <b>script</b> to begin operation.</li>
        </ol>
        <p><b>Note:</b> If you encounter any unexpected behavior or errors, please contact <b>German Garcia</b> immediately.</p>
        """)
        self.topLayout.addWidget(self.textBrowser)

        self.topRightWidget = QtWidgets.QWidget()
        self.topRightGrid = QtWidgets.QGridLayout(self.topRightWidget)

        self.label_direction = QtWidgets.QLabel("Direction")
        self.combo_direction = QtWidgets.QComboBox()
        self.combo_direction.addItems(["Forward", "Backward"])

        self.label_channel = QtWidgets.QLabel("Channel")
        self.combo_channel = QtWidgets.QComboBox()
        self.combo_channel.addItems(["Height", "Error", "Channel 3", "Channel 4", "Channel 5", "Channel 6", "Channel 7", "Channel 8"])

        self.label_processing = QtWidgets.QLabel("Processing")
        self.combo_processing = QtWidgets.QComboBox()
        self.combo_processing.addItems(["None"])

        self.label_color = QtWidgets.QLabel("Color Option")
        self.combo_color = QtWidgets.QComboBox()
        self.combo_color.addItems(["Viridis", "Plasma", "Inferno", "Cividis", "Gray", "Hot"])

        self.topRightGrid.addWidget(self.label_direction, 0, 0)
        self.topRightGrid.addWidget(self.combo_direction, 0, 1)
        self.topRightGrid.addWidget(self.label_channel, 0, 2)
        self.topRightGrid.addWidget(self.combo_channel, 0, 3)
        self.topRightGrid.addWidget(self.label_processing, 1, 0)
        self.topRightGrid.addWidget(self.combo_processing, 1, 1)
        self.topRightGrid.addWidget(self.label_color, 1, 2)
        self.topRightGrid.addWidget(self.combo_color, 1, 3)

        self.topLayout.addWidget(self.topRightWidget)
        self.leftLayout.addWidget(self.topSection)

        # === ORTA BÖLÜM ===
        self.middleSection = QtWidgets.QWidget()
        self.middleLayout = QtWidgets.QHBoxLayout(self.middleSection)

        self.groupBox_scan = QtWidgets.QGroupBox("Scan Parameters")
        groupScanLayout = QtWidgets.QGridLayout(self.groupBox_scan)

        # Her parametre için ayrı değişken
        self.lineEdit_width = QtWidgets.QLineEdit()
        self.lineEdit_width.setText("1e-05")
        groupScanLayout.addWidget(QtWidgets.QLabel("Width:"), 0, 0)
        groupScanLayout.addWidget(self.lineEdit_width, 0, 1)
        groupScanLayout.addWidget(QtWidgets.QLabel("m"), 0, 2)

        self.lineEdit_height = QtWidgets.QLineEdit()
        self.lineEdit_height.setText("1e-05")
        groupScanLayout.addWidget(QtWidgets.QLabel("Height:"), 1, 0)
        groupScanLayout.addWidget(self.lineEdit_height, 1, 1)
        groupScanLayout.addWidget(QtWidgets.QLabel("m"), 1, 2)

        self.lineEdit_xoffset = QtWidgets.QLineEdit()
        self.lineEdit_xoffset.setText("0")
        groupScanLayout.addWidget(QtWidgets.QLabel("X Offset:"), 2, 0)
        groupScanLayout.addWidget(self.lineEdit_xoffset, 2, 1)
        groupScanLayout.addWidget(QtWidgets.QLabel("m"), 2, 2)

        self.lineEdit_yoffset = QtWidgets.QLineEdit()
        self.lineEdit_yoffset.setText("0")
        groupScanLayout.addWidget(QtWidgets.QLabel("Y Offset:"), 3, 0)
        groupScanLayout.addWidget(self.lineEdit_yoffset, 3, 1)
        groupScanLayout.addWidget(QtWidgets.QLabel("m"), 3, 2)

        self.lineEdit_rotation = QtWidgets.QLineEdit()
        self.lineEdit_rotation.setText("0.00")
        groupScanLayout.addWidget(QtWidgets.QLabel("Rotation:"), 4, 0)
        groupScanLayout.addWidget(self.lineEdit_rotation, 4, 1)
        groupScanLayout.addWidget(QtWidgets.QLabel("°"), 4, 2)

        self.lineEdit_pixels_x = QtWidgets.QLineEdit()
        self.lineEdit_pixels_x.setText("64")
        groupScanLayout.addWidget(QtWidgets.QLabel("Pixels X:"), 5, 0)
        groupScanLayout.addWidget(self.lineEdit_pixels_x, 5, 1)
        groupScanLayout.addWidget(QtWidgets.QLabel(""), 5, 2)

        self.lineEdit_pixels_y = QtWidgets.QLineEdit()
        self.lineEdit_pixels_y.setText("64")
        groupScanLayout.addWidget(QtWidgets.QLabel("Pixels Y:"), 6, 0)
        groupScanLayout.addWidget(self.lineEdit_pixels_y, 6, 1)
        groupScanLayout.addWidget(QtWidgets.QLabel(""), 6, 2)

        self.lineEdit_scan_speed = QtWidgets.QLineEdit()
        self.lineEdit_scan_speed.setText("0.4")
        groupScanLayout.addWidget(QtWidgets.QLabel("Scan Speed:"), 7, 0)
        groupScanLayout.addWidget(self.lineEdit_scan_speed, 7, 1)
        groupScanLayout.addWidget(QtWidgets.QLabel("s"), 7, 2)

        # Açıklama
        hint = QtWidgets.QLabel("(Time/ Line)")
        font = QtGui.QFont()
        font.setPointSize(8)
        hint.setFont(font)
        groupScanLayout.addWidget(hint, 8, 0, 1, 2)


        self.btn_set_parameters = QtWidgets.QPushButton("Set Parameters")
        groupScanLayout.addWidget(self.btn_set_parameters, 9, 0, 1, 3)

        self.groupBox_status = QtWidgets.QGroupBox("Scanning Status")
        groupStatusLayout = QtWidgets.QGridLayout(self.groupBox_status)

        # Sol sütun (sabit açıklamalar)
        groupStatusLayout.addWidget(QtWidgets.QLabel("Total Time:"), 0, 0)
        groupStatusLayout.addWidget(QtWidgets.QLabel("Time to Finish:"), 1, 0)
        groupStatusLayout.addWidget(QtWidgets.QLabel("Direction:"), 2, 0)
        groupStatusLayout.addWidget(QtWidgets.QLabel("Line:"), 3, 0)

        # Sağ sütun (güncellenebilir QLabel'lar)
        self.label_total_time = QtWidgets.QLabel("0 h 1 min 4 sec")
        self.label_time_to_finish = QtWidgets.QLabel("0 h 1 min 4 sec")
        self.label_direction = QtWidgets.QLabel("Down")
        self.label_line = QtWidgets.QLabel("2")

        groupStatusLayout.addWidget(self.label_total_time, 0, 1)
        groupStatusLayout.addWidget(self.label_time_to_finish, 1, 1)
        groupStatusLayout.addWidget(self.label_direction, 2, 1)
        groupStatusLayout.addWidget(self.label_line, 3, 1)

        self.middleLayout.addWidget(self.groupBox_scan, stretch=3)
        self.middleLayout.addWidget(self.groupBox_status, stretch=2)
        self.leftLayout.addWidget(self.middleSection)


        # === ALT BÖLÜM ===
        self.bottomSection = QtWidgets.QWidget()
        self.bottomLayout = QtWidgets.QHBoxLayout(self.bottomSection)

        self.groupBox_saving = QtWidgets.QGroupBox("Saving")
        groupSavingLayout = QtWidgets.QVBoxLayout(self.groupBox_saving)

        # Satır 1: Auto Save ve Save Now
        row1 = QtWidgets.QHBoxLayout()
        self.check_auto_save = QtWidgets.QCheckBox("Auto save")
        self.btn_save_now = QtWidgets.QPushButton("Save Now")
        row1.addWidget(self.check_auto_save)
        row1.addWidget(self.btn_save_now)
        groupSavingLayout.addLayout(row1)

        # Satır 2: Path seçimi
        row2 = QtWidgets.QHBoxLayout()
        self.line_path = QtWidgets.QLineEdit("D:\\AFM temp data")
        self.btn_browse = QtWidgets.QPushButton("📁")
        self.btn_browse.setFixedWidth(30)
        self.btn_browse.clicked.connect(self.browse_folder)
        row2.addWidget(self.line_path)
        row2.addWidget(self.btn_browse)
        groupSavingLayout.addLayout(row2)

        # Satır 3: Folder Name (inaktif)
        row3 = QtWidgets.QHBoxLayout()
        label_foldername = QtWidgets.QLabel("Folder Name:")
        self.lineEdit_filename1 = QtWidgets.QLineEdit()
        self.lineEdit_filename1.setDisabled(True)  # İnaktif yapıldı
        row3.addWidget(label_foldername)
        row3.addWidget(self.lineEdit_filename1)
        groupSavingLayout.addLayout(row3)

        # Satır 4: Image File Name
        row4 = QtWidgets.QHBoxLayout()
        label_imgname = QtWidgets.QLabel("Image File Name:")
        self.lineEdit_filename2 = QtWidgets.QLineEdit()
        row4.addWidget(label_imgname)
        row4.addWidget(self.lineEdit_filename2)
        groupSavingLayout.addLayout(row4)



        self.groupBox_options = QtWidgets.QGroupBox("Scan Options")
        groupOptionsLayout = QtWidgets.QVBoxLayout(self.groupBox_options)

        # Butonları tanımla ve self. ile adlandır
        self.pushButton_topdown = QtWidgets.QPushButton("Scan TopDown")
        self.pushButton_topdown.setEnabled(True)
        groupOptionsLayout.addWidget(self.pushButton_topdown)

        self.pushButton_downup = QtWidgets.QPushButton("Scan DownUp")
        self.pushButton_downup.setEnabled(True)
        groupOptionsLayout.addWidget(self.pushButton_downup)

        self.pushButton_bouncing = QtWidgets.QPushButton("Scan Bouncing")
        self.pushButton_bouncing.setEnabled(True)
        groupOptionsLayout.addWidget(self.pushButton_bouncing)

        self.pushButton_stop = QtWidgets.QPushButton("Stop")
        self.pushButton_stop.setEnabled(True)
        groupOptionsLayout.addWidget(self.pushButton_stop)

        self.pushButton_pause = QtWidgets.QPushButton("Pause/Resume")
        self.pushButton_pause.setEnabled(False)
        groupOptionsLayout.addWidget(self.pushButton_pause)

        self.pushButton_continuous = QtWidgets.QPushButton("Continuous Scan")
        self.pushButton_continuous.setEnabled(False)
        groupOptionsLayout.addWidget(self.pushButton_continuous)


        self.bottomLayout.addWidget(self.groupBox_saving, stretch=3)
        self.bottomLayout.addWidget(self.groupBox_options, stretch=2)
        self.leftLayout.addWidget(self.bottomSection)
        self.leftLayout.addStretch()
        self.centralLayout.addWidget(self.leftPanel)

        # ---------------------- SAĞ PANEL ----------------------
        self.rightPanel = QtWidgets.QWidget(self.centralwidget)
        self.rightLayout = QtWidgets.QVBoxLayout(self.rightPanel)

        self.label_monitor = QtWidgets.QLabel("MONITOR")
        font = QtGui.QFont()
        font.setPointSize(16)
        font.setBold(True)
        self.label_monitor.setFont(font)
        self.label_monitor.setAlignment(QtCore.Qt.AlignCenter)

        self.plotArea = QtWidgets.QWidget()
        self.plotArea.setStyleSheet("background-color: #fff8dc; border: 1px dashed #999900;")

        self.rightLayout.addWidget(self.label_monitor)
        self.rightLayout.addWidget(self.plotArea, stretch=1)

        self.centralLayout.addWidget(self.rightPanel, stretch=3)

        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def browse_folder(self):
        directory = QtWidgets.QFileDialog.getExistingDirectory(None, "Select Directory")
        if directory:
            self.line_path.setText(directory)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "LNET Control GUI"))

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
