import PyQt5
import PyQt5.QtWidgets as Qt
from PyQt5.QtCore import QTimer
import pyThorlabsPM100x

# --- NKT Tools import ---
from nkt_tools.extreme import Extreme

class PowerControlPID:
    def __init__(self, laser, pm_interface, update_interval=0.5):
        self.laser = laser
        self.pm_interface = pm_interface
        self.target_power = None  # in mW
        self.kp =500   # Proportional gain (tune as needed)
        self.ki = 0.01   # Integral gain (tune as needed)
        self.kd = 1   # Derivative gain (tune as needed)
        self.integral = 0
        self.last_error = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.control_step)
        self.update_interval = int(update_interval * 1000)
        self.max_step = 50  # Max current step per update (in permille, tune as needed)
        self.min_current = 0
        self.max_current = 1000  # permille (0-1000), as required by register 38
        self.current_written_callback = None  # Callback for GUI update

    def set_current_written_callback(self, callback):
        self.current_written_callback = callback

    def start(self, target_power):
        self.target_power = target_power  # in mW
        self.integral = 0
        self.last_error = 0
        # Set laser to power lock mode (mode 4) and turn emission ON
        try:
            self.laser.set_mode(4)  # Power Lock mode
            self.laser.set_emission(True)  # Turn emission ON
        except Exception as e:
            print(f"Failed to set power lock mode or emission: {e}")
        self.timer.start(self.update_interval)

    def stop(self):
        self.timer.stop()
        # No set_power_lock to disable, so nothing else needed

    def control_step(self):
        current_power = self.pm_interface.output['Power']  # in mW
        try:
            setpoint = self.target_power
            current_power_w = self.pm_interface.output['Power']  # in Watts

            # Get scheduled PID gains based on measured power (in Watts)
            kp, ki, kd = self.get_pid_gains(current_power_w)

            # Read current level (percent), convert to permille
            current_level_permille = self.laser.current_level * 10
            error = setpoint - current_power
            self.integral += error * (self.update_interval / 1000)
            derivative = (error - self.last_error) / (self.update_interval / 1000)
            self.last_error = error

            # PID output (in permille steps)
            output = kp * error + ki * self.integral + kd * derivative
            step = max(min(output, self.max_step), -self.max_step)
            new_current = current_level_permille + step
            new_current = max(self.min_current, min(self.max_current, new_current))  # Clamp to 0-1000 permille

            # Stop updating if setpoint is reached (within tolerance)
            tolerance = 0.01 * setpoint  # 1% tolerance
            setpoint_w = setpoint / 1000.0 if setpoint is not None else None

            # --- STOP PID and register update if power reached flag is on ---
            if setpoint_w is not None and current_power_w >= setpoint_w:
                self.timer.stop()
                return

            if abs(error) <= tolerance:
                self.timer.stop()
                return

            # Only increase, never overshoot
            if error > 0 and new_current > self.max_current:
                new_current = self.max_current
            elif error < 0 and new_current < self.min_current:
                new_current = self.min_current

            # Use set_current (percent, 0-100)
            self.laser.set_current(new_current / 10)
            if self.current_written_callback:
                self.current_written_callback(int(new_current))
        except Exception as e:
            print(f"PID error: {e}")
            self.stop()

    def get_pid_gains(self, setpoint_w):
        # setpoint_w is in Watts
        # Each tuple: (max_value_in_watts, Kp, Ki, Kd)
        schedule = [
            (0.0000035, 2000.0, 0.01, 0.3),   # 3.5 uW
            (0.00205,     300.0, 0.01, 0.3),   # 2.05 mW
            (0.00505,     30.0, 0.01, 0.3),   # 5.05 mW
            (0.01005,     15.0, 0.01, 0.3),   # 10.05 mW
            (0.02005,      8.0, 0.01, 0.3),   # 20.05 mW
            (0.02205,      4.0, 0.01, 0.3),   # 22.05 mW
            (1.0,          1.0, 0.01, 0.3),   # 1 W (catch-all)
        ]
        for max_val, kp, ki, kd in schedule:
            if setpoint_w <= max_val:
                return kp, ki, kd
        return schedule[-1][1:]  # Default to last

# --- GUI setup ---
app = Qt.QApplication([])
window = Qt.QWidget()

widget_containing_interface_GUI = Qt.QWidget()
widget_containing_interface_GUI.setStyleSheet(".QWidget {\n"
            + "border: 1px solid black;\n"
            + "border-radius: 4px;\n"
            + "}")

# Powermeter interface
Interface = pyThorlabsPM100x.interface(app=app)
Interface.verbose = False

# Powermeter GUI
gui = pyThorlabsPM100x.gui(interface=Interface, parent=widget_containing_interface_GUI, plot=False)

# --- NKT SuperK Extreme laser object ---
laser = Extreme()  # Will auto-detect port

# --- PID controller ---
pid = PowerControlPID(laser, Interface)

# --- Additional GUI ---
gridlayoutwidget = Qt.QWidget()
gridlayout = Qt.QGridLayout()
gridlayout.addWidget(Qt.QLabel("Additional GUI 1"), 0, 0)
gridlayout.addWidget(Qt.QLabel("Additional GUI 2"), 1, 0)
gridlayout.addWidget(Qt.QLabel("Additional GUI 3"), 0, 1)
gridlayout.addWidget(Qt.QLabel("Additional GUI 4"), 1, 1)
gridlayoutwidget.setLayout(gridlayout)

# --- Power set controls ---
power_set_widget = Qt.QWidget()
power_set_layout = Qt.QHBoxLayout()
power_set_widget.setLayout(power_set_layout)
power_label = Qt.QLabel("Set Power (uW):")  # Changed to uW
power_spin = Qt.QDoubleSpinBox()
power_spin.setDecimals(2)
power_spin.setMinimum(0.0)
power_spin.setMaximum(2_000_000.0)  # 2 W in uW
power_spin.setValue(10000.0)        # Default 10 mW in uW
set_btn = Qt.QPushButton("Set & Reach Power")
stop_btn = Qt.QPushButton("Stop PID")
emission_off_btn = Qt.QPushButton("Turn Emission OFF")  # New button

# --- Indicator for current level register ---
current_level_label = Qt.QLabel("Current Level Register (permille):")
current_level_value = Qt.QLabel("N/A")

# --- Indicator for power reached ---
power_reached_label = Qt.QLabel("Power Reached:")
power_reached_value = Qt.QLabel("NO")
power_reached_value.setStyleSheet("color: red; font-weight: bold;")

power_set_layout.addWidget(power_label)
power_set_layout.addWidget(power_spin)
power_set_layout.addWidget(set_btn)
power_set_layout.addWidget(stop_btn)
power_set_layout.addWidget(emission_off_btn)
power_set_layout.addWidget(current_level_label)
power_set_layout.addWidget(current_level_value)
power_set_layout.addWidget(power_reached_label)
power_set_layout.addWidget(power_reached_value)

def update_current_level(val):
    current_level_value.setText(str(val))

pid.set_current_written_callback(update_current_level)

def update_power_reached():
    try:
        current_power = Interface.output['Power']  # in Watts
        setpoint_mw = pid.target_power             # in mW
        setpoint_w = setpoint_mw / 1000.0 if setpoint_mw is not None else None
        if setpoint_w is not None and current_power >= setpoint_w:
            power_reached_value.setText("YES")
            power_reached_value.setStyleSheet("color: green; font-weight: bold;")
        else:
            power_reached_value.setText("NO")
            power_reached_value.setStyleSheet("color: red; font-weight: bold;")
    except Exception:
        power_reached_value.setText("NO")
        power_reached_value.setStyleSheet("color: red; font-weight: bold;")

# Timer to update the power reached indicator every 500 ms
power_reached_timer = QTimer()
power_reached_timer.timeout.connect(update_power_reached)
power_reached_timer.start(500)

def on_set_power():
    # Convert uW to mW for the PID controller
    target = power_spin.value() / 1000.0
    pid.start(target)

def on_stop_pid():
    pid.stop()

def on_emission_off():
    try:
        laser.set_emission(False)
    except Exception as e:
        print(f"Failed to turn emission off: {e}")

set_btn.clicked.connect(on_set_power)
stop_btn.clicked.connect(on_stop_pid)
emission_off_btn.clicked.connect(on_emission_off)

layout = Qt.QVBoxLayout()
layout.addWidget(widget_containing_interface_GUI)
layout.addWidget(gridlayoutwidget)
layout.addWidget(power_set_widget)
layout.addStretch(1)
window.setLayout(layout)

window.show()
app.exec()