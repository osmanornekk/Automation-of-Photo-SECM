from ctypes import cdll, c_int, c_uint, c_double
import atexit
from time import sleep
import numpy as np
import nifpga
import time
import sys 
import os
class Madpiezo():
    def __init__(self):
        # provide valid path to Madlib.dll. Madlib.h and Madlib.lib should also be in the same folder
        path_to_dll =  r"C:\Program Files\Mad City Labs\NanoDrive\Madlib.dll"
        self.madlib = cdll.LoadLibrary(path_to_dll)
        self.handler = None  # Do not grab handle here
        atexit.register(self.mcl_close)

    def grab_handle_by_type(self, device_type):
        """
        Grabs a handle to a specific type of Nano-Drive.
        device_type: int, use values from the documentation (e.g., 8195 for Nano-Drive Three Axis)
        Returns: int handle or 0 on failure
        """
        MCL_GrabHandle = self.madlib['MCL_GrabHandle']
        MCL_GrabHandle.restype = c_int
        MCL_GrabHandle.argtypes = [c_int]
        handler = MCL_GrabHandle(c_int(device_type))
        if handler == 0:
            print(f"Failed to grab handle for device type {device_type}")
        self.handler = handler  # Store handler for later use
        return handler

    def mcl_start(self):
        mcl_init_handle = self.madlib['MCL_InitHandle']
        mcl_init_handle.restype = c_int
        handler = mcl_init_handle()
        if(handler==0):
            print("MCL init error")
            return -1
        return handler
    def mcl_read(self,axis_number):
        mcl_single_read_n = self.madlib['MCL_SingleReadN']
        mcl_single_read_n.restype = c_double
        return  mcl_single_read_n(c_uint(axis_number), c_int(self.handler))
    def mcl_write(self,position, axis_number):
        mcl_single_write_n = self.madlib['MCL_SingleWriteN']
        mcl_single_write_n.restype = c_int
        error_code = mcl_single_write_n(c_double(position), c_uint(axis_number), c_int(self.handler))
        if(error_code !=0):
            print("MCL write error = ", error_code)
        return error_code
    def goxy(self,x_position,y_position):
        self.mcl_write(x_position,1)
        self.mcl_write(y_position,2)
    def goz(self,z_position):
        self.mcl_write(z_position,3)
    def get_position(self):
        return self.mcl_read(1), self.mcl_read(2), self.mcl_read(3)
    def mcl_close(self):
        mcl_release_all = self.madlib['MCL_ReleaseAllHandles']
        mcl_release_all()
