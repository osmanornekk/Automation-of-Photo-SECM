# -*- coding: utf-8 -*-
"""
Created on Wed Mar 26 00:45:12 2025

@author: Osman
"""

# imports for main tab
import sys
import time
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QFileDialog
from PyQt5 import QtCore
from PyQt5.QtCore import QTimer
#from lnet_project import Ui_MainWindow  # main gui coming from converted .ui file
from maintab_gui import Ui_MainWindow
from CVp2p import CVScanGUI  
from CAp2p import CAScanGUI

import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import random  
import csv

import sys
import os
import time
# Get the parent directory and add it to sys.path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import aespm as ae
# Now you can import AFMController
from lbni_controller import AFMController

from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from PyQt5.QtWidgets import QVBoxLayout
from PyQt5 import QtWidgets

from PyQt5.QtWidgets import QFileDialog

# imports for cv tab

import sys
import os
sys.path.insert(0, r"D:\Downloads\RePySPM-main\RePySPM-main\RePySPM\spm_controller\EC-Lab Development Package\Examples\Python")
import numpy as np
import time
from datetime import datetime
from PyQt5 import QtWidgets, QtCore
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

# EC-Lab ve piezo class imports
from mcl_piezo_lib import Madpiezo
import kbio.kbio_types as KBIO
from kbio.c_utils import c_is_64b
from kbio.kbio_api import KBIO_api
from kbio.kbio_tech import ECC_parm, get_experiment_data, get_info_data, make_ecc_parm, make_ecc_parms


# import for ca tab 


class CAMeasurementApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)


        # tab2
        #self.cv_gui = CVScanGUI()  # CVScanGUI 

        # locate into tab_2
        #layout = QtWidgets.QVBoxLayout(self.ui.tab_2)
        #layout.addWidget(self.cv_gui)

        
        # tab3
        #self.ca_gui = CAScanGUI()  # CAScanGUI 

        # locate into tab_3
        #layout = QtWidgets.QVBoxLayout(self.ui.tab_3)
        #layout.addWidget(self.ca_gui)
        


        # scan updown
        # AFM scannning button connections
        self.ui.pushButton_topdown.clicked.connect(self.handle_scan_topdown)
        self.ui.pushButton_downup.clicked.connect(self.handle_scan_downup)
        self.ui.pushButton_bouncing.clicked.connect(self.handle_scan_bouncing)

        # update params and set total time
        self.ui.btn_set_parameters.clicked.connect(self.update_total_time)

        self.timer = QtCore.QTimer()
        self.timer.timeout.connect(self.update_all_scan_info)
        self.afm = AFMController(r"C:\Users\adminlnet\OpenSPM-source")  # prevents re-initialization of AFMController

        self.ui.pushButton_stop.clicked.connect(self.handle_scan_stop)
        self.ui.btn_save_now.clicked.connect(self.save_now)

        #self.ui.pushButton_8.clicked.connect(self.select_save_location)
        self.ui.check_auto_save.stateChanged.connect(self.handle_autosave_checkbox)
        self.ui.combo_channel.currentIndexChanged.connect(self.plot_channel_data)

        self.scan_line = None  # for line tracking




    def handle_scan_topdown(self):
        project_path = r"C:\Users\adminlnet\OpenSPM-source"
        
        afm = AFMController(project_path)

        print("TopDown Scan started.")


        afm.scan_control.scan_down()
        self.timer.start(300)  # 0.3 seconds interval for updating scan info

    def handle_scan_downup(self):
        project_path = r"C:\Users\adminlnet\OpenSPM-source"
        
        afm = AFMController(project_path)

        print("DownUp Scan started.")

        afm.scan_control.scan_up()
        self.timer.start(300)  # 0.3 seconds interval for updating scan info

    def handle_scan_bouncing(self):
        project_path = r"C:\Users\adminlnet\OpenSPM-source"
        
        afm = AFMController(project_path)

        print("Bouncing Scan started.")

        afm.scan_control.scan_bouncing()
        self.timer.start(300)  # 0.3 seconds interval for updating scan info

    def update_total_time(self):

        # set other parameters

        # width
        value_str = self.ui.lineEdit_width.text()
        try:
            value = float(value_str)
        except ValueError:
            print("Invalid Number!")
            value = 0.0  # or default value
        self.afm.scan_parameters.set_width(value)

        # height
        value2_str = self.ui.lineEdit_height.text()
        try:
            value2 = float(value2_str)
        except ValueError:
            print("Invalid Number!")
            value2 = 0.0  # or default value
        self.afm.scan_parameters.set_height(value2)

        # offset x
        xoff_str = self.ui.lineEdit_xoffset.text()
        try:
            xoff = float(xoff_str)
        except ValueError:
            print("Invalid Number!")
            value2 = 0.0  # or default value
        self.afm.scan_parameters.set_offset_x(xoff)

        # offset y
        yoff_str = self.ui.lineEdit_yoffset.text()
        try:
            yoff = float(yoff_str)
        except ValueError:
            print("Invalid Number!")
            value2 = 0.0  # or default value
        self.afm.scan_parameters.set_offset_y(xoff)


        # rotation
        rot_str = self.ui.lineEdit_rotation.text()
        try:
            rotation = float(rot_str)
        except ValueError:
            print("Invalid Number!")
            value2 = 0.0  # or default value
        self.afm.scan_parameters.set_rotation(rotation)


        # pixels(x pixsels)
        
        xpixel_str = self.ui.lineEdit_pixels_x.text()
        try:
            xpixel = float(xpixel_str)
        except ValueError:
            print("Invalid Number!")
            value2 = 0.0  # or default value
        self.afm.scan_parameters.set_pixels_x(xpixel)

        # pixels(y pixsels)
        
        ypixel_str = self.ui.lineEdit_pixels_y.text()
        try:
            ypixel = float(ypixel_str)
        except ValueError:
            print("Invalid Number!")
            value2 = 0.0  # or default value
        self.afm.scan_parameters.set_pixels_y(ypixel)

        # scan speed
        scanspeed_str = self.ui.lineEdit_scan_speed.text()
        try:
            scanspeed = float(scanspeed_str)
        except ValueError:
            print("Invalid Number!")
            value2 = 0.0  # or default value
        self.afm.scan_parameters.set_scan_speed(scanspeed)




        total_time = self.handle_total_time()
        self.ui.label_total_time.setText(total_time)
        print("Parameters are set")

    def handle_total_time(self):
        project_path = r"C:\Users\adminlnet\OpenSPM-source"
        
        afm = AFMController(project_path)

        return afm.scan_control.get_total_time()
    
    def update_all_scan_info(self):
        # time
        time_str = self.afm.scan_control.get_time_to_finish()
        if time_str.strip() == "0 h 0 min 0 sec":
            self.timer.stop()
            print("Scan finished")
        else:
            self.ui.label_time_to_finish.setText(time_str)

        # line
        line = self.afm.scan_control.get_line()
        self.ui.label_line.setText(str(line))

        # direction
        direction = self.afm.scan_control.get_scan_direction()
        self.ui.label_direction.setText(str(direction))


        self.plot_channel_data()



    def handle_scan_stop(self):
        self.afm.scan_control.scan_stop()

        # stop timer
        if self.timer.isActive():
            self.timer.stop()

        print("Scan manually stopped.")

    def handle_save_button_click(self):
        path_name = self.ui.line_path.text().strip()
        # set path
        self.afm.scan_control.set_path(path_name)
        print(f"Path set to: {path_name}")




        base_name = self.ui.lineEdit_filename2.text().strip()
        """
        # date-time format
        from datetime import datetime
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

        # check if checkbox is checked for timestamp
        if self.ui.checkBox_3.isChecked():
            full_name = f"{timestamp}_{base_name}"
        else:
            full_name = base_name

        # Spinbox format
        spin_value = self.ui.spinBox_2.value()
        full_name += f"_{spin_value:04d}"
        """
        full_name = base_name
        # set file name
        self.afm.scan_control.set_file_name(full_name)
        print(f"File name set to: {full_name}")

        # increase spinbox
        #self.ui.spinBox_2.setValue(spin_value + 1)

    def save_now(self):
        self.handle_save_button_click()
        self.afm.scan_control.scan_save_now()


    def select_save_location(self):
        folder = QFileDialog.getExistingDirectory(self, "Select Save Folder")

        if folder:
            self.ui.line_path.setText(folder) 
            print(f"Selected save path: {folder}")

    def plot_channel_data(self):
        """
        Plots the selected channel with selected direction and colormap.
        Adds or updates a red horizontal line to indicate current scan line.
        """
        channel_name = self.ui.combo_channel.currentText()
        fb_index = self.ui.combo_direction.currentIndex()  # 0 = Forward, 1 = Backward
        selected_cmap = self.ui.combo_color.currentText().lower()  # Color map

        img_e = self.afm.image.get_channel(channel_name, fb_index)
        current_line = self.afm.scan_control.get_line()

        print(f"Selected channel: {channel_name}, Direction: {'Forward' if fb_index == 0 else 'Backward'}")
        print(img_e)

        if not hasattr(self, 'im') or self.im is None:


            fig = Figure()
            fig.tight_layout()
            self.canvas = FigureCanvas(fig)
            self.canvas.setSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)

            self.ax = fig.add_subplot(111)
            self.im = self.ax.imshow(img_e, cmap=selected_cmap)
            fig.colorbar(self.im, ax=self.ax)

            # İlk scan çizgisini oluştur
            self.scan_line = self.ax.axhline(current_line, color='red', linewidth=1)

            if self.ui.plotArea.layout() is None:
                layout = QVBoxLayout()
                self.ui.plotArea.setLayout(layout)
            self.ui.plotArea.layout().addWidget(self.canvas)

        else:
            self.im.set_data(img_e)
            self.im.set_cmap(selected_cmap)

            # scale the color limits based on measured non-zero values

            nonzero_values = img_e[img_e != 0]
            if nonzero_values.size > 0:
                vmin = nonzero_values.min()
                vmax = nonzero_values.max()
            else:
                vmin, vmax = 0, 1

            self.im.set_clim(vmin=vmin, vmax=vmax)

            # update the scan line position
            if hasattr(self, 'scan_line') and self.scan_line:
                self.scan_line.set_ydata([current_line, current_line])

            self.canvas.draw()


    # Autosave checkbox handler
    def handle_autosave_checkbox(self, _):
        is_enabled = self.ui.check_auto_save.isChecked()
        print(f"Autosave {'enabled' if is_enabled else 'disabled'}")
        
        self.afm.scan_control.scan_auto_save(is_enabled)









if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CAMeasurementApp()
    window.show()
    sys.exit(app.exec_())