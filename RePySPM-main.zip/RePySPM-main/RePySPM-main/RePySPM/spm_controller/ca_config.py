from dataclasses import dataclass
from kbio.kbio_tech import ECC_parm

@dataclass
class ca_step:
    voltage: float
    duration: float
    vs_init: bool = False

# Örnek adımlar
steps = [
    ca_step(0.2, 1),
    ca_step(0, 1, True),
]

repeat_count = 0
record_dt = 0.0001
record_dI = 0.00000000000010
i_range = "I_RANGE_AUTO"

CA_parms = {
    "voltage_step": ECC_parm("Voltage_step", float),
    "duration_step": ECC_parm("Duration_step", float),
    "vs_init": ECC_parm("vs_initial", bool),
    "nb_steps": ECC_parm("Step_number", int),
    "record_dt": ECC_parm("Record_every_dT", float),
    "record_dI": ECC_parm("Record_every_dI", float),
    "repeat": ECC_parm("N_Cycles", int),
    "I_range": ECC_parm("I_Range", int),
}
