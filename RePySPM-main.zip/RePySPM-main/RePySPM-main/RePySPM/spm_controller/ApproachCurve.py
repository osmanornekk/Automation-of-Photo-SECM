import sys
import os
sys.path.insert(0, r"D:\Downloads\RePySPM-main\RePySPM-main\RePySPM\spm_controller\EC-Lab Development Package\Examples\Python")

import time
import numpy as np
from datetime import datetime
from PyQt5 import QtWidgets, QtCore
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

from mcl_piezo_lib import Madpiezo
import kbio.kbio_types as KBIO
from kbio.c_utils import c_is_64b
from kbio.kbio_api import KBIO_api
from kbio.kbio_tech import ECC_parm, make_ecc_parm, make_ecc_parms, get_experiment_data, get_info_data

class ApproachCurveGUI(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Approach Curve Procedure")
        self.resize(1400, 700)
        self.layout = QtWidgets.QHBoxLayout(self)
        self.setLayout(self.layout)

        # --- Left: Parameters ---
        param_widget = QtWidgets.QWidget()
        param_layout = QtWidgets.QFormLayout(param_widget)

        self.start_pos = QtWidgets.QDoubleSpinBox(); self.start_pos.setValue(30)
        self.finish_pos = QtWidgets.QDoubleSpinBox(); self.finish_pos.setValue(0)
        self.max_stepsize = QtWidgets.QDoubleSpinBox(); self.max_stepsize.setDecimals(4); self.max_stepsize.setValue(0.002)
        self.min_stepsize = QtWidgets.QDoubleSpinBox(); self.min_stepsize.setDecimals(4); self.min_stepsize.setValue(0.002)
        self.n_steps = QtWidgets.QSpinBox(); self.n_steps.setValue(1000)
        self.wait_time = QtWidgets.QDoubleSpinBox(); self.wait_time.setValue(1)
        self.stop_value = QtWidgets.QDoubleSpinBox(); self.stop_value.setValue(99)
        self.n_avg = QtWidgets.QSpinBox(); self.n_avg.setValue(10)

        param_layout.addRow("Start Position (um):", self.start_pos)
        param_layout.addRow("Finish Position (um):", self.finish_pos)
        param_layout.addRow("Max Stepsize (um):", self.max_stepsize)
        param_layout.addRow("Min Stepsize (um):", self.min_stepsize)
        param_layout.addRow("# Steps for i_inf:", self.n_steps)
        param_layout.addRow("Wait time (s):", self.wait_time)
        param_layout.addRow("% Stop value:", self.stop_value)
        param_layout.addRow("# Points for Averaging:", self.n_avg)

        # --- CA Parameters ---
        self.ca_voltage = QtWidgets.QDoubleSpinBox(); self.ca_voltage.setValue(0.2)
        self.ca_duration = QtWidgets.QDoubleSpinBox(); self.ca_duration.setValue(2.0)
        self.ca_repeat = QtWidgets.QSpinBox(); self.ca_repeat.setValue(1)
        self.ca_i_range = QtWidgets.QComboBox()
        for label, key in [
            ("100 pA", "I_RANGE_100pA"),
            ("1 nA", "I_RANGE_1nA"),
            ("10 nA", "I_RANGE_10nA"),
            ("100 nA", "I_RANGE_100nA"),
            ("1 uA", "I_RANGE_1uA"),
            ("10 uA", "I_RANGE_10uA"),
            ("100 uA", "I_RANGE_100uA"),
            ("1 mA", "I_RANGE_1mA"),
            ("10 mA", "I_RANGE_10mA"),
            ("100 mA", "I_RANGE_100mA"),
            ("1 A", "I_RANGE_1A"),
            ("Auto", "I_RANGE_AUTO"),
        ]:
            self.ca_i_range.addItem(label, key)
        self.ca_i_range.setCurrentText("Auto")
        param_layout.addRow("CA Voltage (V):", self.ca_voltage)
        param_layout.addRow("CA Duration (s):", self.ca_duration)
        param_layout.addRow("CA Repeat:", self.ca_repeat)
        param_layout.addRow("CA I Range:", self.ca_i_range)

        # --- Piezo connect ---
        self.piezo_status = QtWidgets.QLabel("Disconnected")
        self.piezo_status.setStyleSheet("color: red;")
        self.piezo_connect_btn = QtWidgets.QPushButton("Connect Piezo")
        self.piezo_connect_btn.clicked.connect(self.connect_piezo)
        param_layout.addRow(self.piezo_status, self.piezo_connect_btn)

        # --- Piezo position display ---
        self.piezo_position_label = QtWidgets.QLabel("Position: N/A, N/A, N/A")
        param_layout.addRow("Piezo Position:", self.piezo_position_label)

        # --- Start/Stop buttons ---
        self.start_btn = QtWidgets.QPushButton("START AC")
        self.stop_btn = QtWidgets.QPushButton("STOP AC")
        self.start_btn.clicked.connect(self.start_approach)
        self.stop_btn.clicked.connect(self.stop_approach)
        param_layout.addRow(self.start_btn, self.stop_btn)

        # --- Status ---
        self.status = QtWidgets.QLabel("")
        param_layout.addRow(self.status)

        self.layout.addWidget(param_widget, stretch=0)

        # --- Right: Plot ---
        self.fig, self.ax = plt.subplots(figsize=(10, 6))
        self.canvas = FigureCanvas(self.fig)
        self.layout.addWidget(self.canvas, stretch=1)
        self.ax.set_xlabel("Distance (um)")
        self.ax.set_ylabel("Current (A)")
        self.ax.set_title("Approach Curve")
        self.line, = self.ax.plot([], [], 'o', color='white', markersize=3)
        self.ax.set_facecolor('black')
        self.fig.patch.set_facecolor('white')
        self.canvas.draw()

        # --- Data ---
        self.piezo = None
        self._stop_requested = False

        # --- Timer for piezo position update ---
        self.position_timer = QtCore.QTimer(self)
        self.position_timer.setInterval(500)  # ms
        self.position_timer.timeout.connect(self.update_piezo_position)

        # --- Piezo manual move controls ---
        self.manual_step_size = QtWidgets.QDoubleSpinBox()
        self.manual_step_size.setDecimals(4)
        self.manual_step_size.setValue(0.002)
        self.manual_step_size.setSingleStep(0.001)
        param_layout.addRow("Manual Step Size (um):", self.manual_step_size)

        self.move_up_btn = QtWidgets.QPushButton("Move Up (+Z)")
        self.move_down_btn = QtWidgets.QPushButton("Move Down (-Z)")
        self.move_up_btn.clicked.connect(self.move_z_up)
        self.move_down_btn.clicked.connect(self.move_z_down)
        move_btn_layout = QtWidgets.QHBoxLayout()
        move_btn_layout.addWidget(self.move_up_btn)
        move_btn_layout.addWidget(self.move_down_btn)
        param_layout.addRow("Manual Z Move:", move_btn_layout)

    def connect_piezo(self):
        try:
            self.piezo = Madpiezo()
            handle = self.piezo.grab_handle_by_type(8705)  # Connect to device 8705
            if handle == 0 or handle == -1:
                raise Exception("Failed to grab handle for device type 8705")
            self.piezo.handler = handle
            self.piezo_status.setText("Connected")
            self.piezo_status.setStyleSheet("color: green;")
            self.position_timer.start()
        except Exception as e:
            self.piezo = None
            self.piezo_status.setText("Connection Failed")
            self.piezo_status.setStyleSheet("color: red;")
            self.status.setText(f"Piezo connection failed: {e}")
            self.position_timer.stop()

    def update_piezo_position(self):
        if self.piezo is not None and self.piezo.handler:
            try:
                # Only read Z position
                z = self.piezo.mcl_read(3)
                self.piezo_position_label.setText(f"Z Position: {z:.4f}")
            except Exception as e:
                self.piezo_position_label.setText("Z Position: Error")
        else:
            self.piezo_position_label.setText("Z Position: N/A")

    def stop_approach(self):
        self._stop_requested = True
        self.status.setText("Stop requested.")

    def start_approach(self):
        self._stop_requested = False
        self.status.setText("Starting approach...")
        QtWidgets.QApplication.processEvents()

        # --- Piezo check ---
        if self.piezo is None:
            self.status.setText("Piezo not connected!")
            return

        # --- EC-Lab setup ---
        verbosity = 1
        address = "192.109.209.128"
        channel = 1
        binary_path = "C:/EC-Lab Development Package/lib"
        DLL_file = "EClib64.dll" if c_is_64b else "EClib.dll"
        DLL_path = f"{binary_path}{os.sep}{DLL_file}"
        api = KBIO_api(DLL_path)
        id_, device_info = api.Connect(address)
        board_type = api.GetChannelBoardType(id_, channel)
        ca_tech_file = "ca.ecc"

        # --- CA parameters ---
        CA_parms = {
            "voltage_step": ECC_parm("Voltage_step", float),
            "duration_step": ECC_parm("Duration_step", float),
            "vs_init": ECC_parm("vs_initial", bool),
            "nb_steps": ECC_parm("Step_number", int),
            "record_dt": ECC_parm("Record_every_dT", float),
            "record_dI": ECC_parm("Record_every_dI", float),
            "repeat": ECC_parm("N_Cycles", int),
            "I_range": ECC_parm("I_Range", int),
        }
        voltage = self.ca_voltage.value()
        duration = self.ca_duration.value()
        repeat = self.ca_repeat.value()
        i_range_key = self.ca_i_range.currentData()

        # Only one step for CA
        p_voltage_step = make_ecc_parm(api, CA_parms["voltage_step"], voltage, 0)
        p_duration_step = make_ecc_parm(api, CA_parms["duration_step"], duration, 0)
        p_vs_init = make_ecc_parm(api, CA_parms["vs_init"], False, 0)
        p_nb_steps = make_ecc_parm(api, CA_parms["nb_steps"], 0)
        p_record_dt = make_ecc_parm(api, CA_parms["record_dt"], 0.01)
        p_record_dI = make_ecc_parm(api, CA_parms["record_dI"], 0.0)
        p_repeat = make_ecc_parm(api, CA_parms["repeat"], repeat)
        p_I_range = make_ecc_parm(api, CA_parms["I_range"], KBIO.I_RANGE[i_range_key].value)

        ca_parms = make_ecc_parms(
            api,
            p_voltage_step,
            p_duration_step,
            p_vs_init,
            p_nb_steps,
            p_record_dt,
            p_record_dI,
            p_I_range,
            p_repeat
        )

        # --- Output CSV ---
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_csv = f"approach_curve_{timestamp}.csv"
        csvfile = open(out_csv, "w")
        csvfile.write("Distance (um),Current (A)\n")

        # --- Start CA experiment ---
        api.LoadTechnique(id_, channel, ca_tech_file, ca_parms, first=True, last=True, display=(verbosity > 1))
        api.StartChannel(id_, channel)

        # --- Approach loop ---
        start = self.start_pos.value()
        finish = self.finish_pos.value()
        n_steps = self.n_steps.value()
        wait_time = self.wait_time.value()
        step_size = (finish - start) / n_steps

        distances = []
        currents = []

        for i in range(n_steps):
            if self._stop_requested:
                self.status.setText("Approach stopped by user.")
                break

            # Move piezo
            pos = start + i * step_size
            try:
                self.piezo.goxy(pos, 0)
            except Exception as e:
                self.status.setText(f"Piezo move error: {e}")
                break

            time.sleep(wait_time)

            # Read CA current (get last value from EC-Lab)
            data = api.GetData(id_, channel)
            status, tech_name = get_info_data(api, data)
            current = np.nan
            for output in get_experiment_data(api, data, tech_name, board_type):
                if len(output) >= 3:
                    i_raw = output[2]
                    current = api.ConvertChannelNumericIntoSingle(int(i_raw, 16), board_type)
            distances.append(pos)
            currents.append(current)
            csvfile.write(f"{pos},{current}\n")
            csvfile.flush()

            # Update plot
            self.line.set_data(distances, currents)
            self.ax.relim()
            self.ax.autoscale_view()
            self.canvas.draw()
            QtWidgets.QApplication.processEvents()

        csvfile.close()
        api.Disconnect(id_)
        self.status.setText(f"Approach complete. Data saved to {out_csv}")

    def move_z_up(self):
        if self.piezo is not None and self.piezo.handler:
            try:
                current_z = self.piezo.mcl_read(3)
                step = self.manual_step_size.value()
                self.piezo.mcl_write(current_z + step, 3)
                self.status.setText(f"Moved Z up by {step} um")
            except Exception as e:
                self.status.setText(f"Move up error: {e}")

    def move_z_down(self):
        if self.piezo is not None and self.piezo.handler:
            try:
                current_z = self.piezo.mcl_read(3)
                step = self.manual_step_size.value()
                self.piezo.mcl_write(current_z - step, 3)
                self.status.setText(f"Moved Z down by {step} um")
            except Exception as e:
                self.status.setText(f"Move down error: {e}")

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    gui = ApproachCurveGUI()
    gui.show()
    sys.exit(app.exec_())