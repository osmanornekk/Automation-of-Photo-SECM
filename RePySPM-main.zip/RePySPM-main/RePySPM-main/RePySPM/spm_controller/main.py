import sys
from PyQt5 import QtWidgets
from gui_main import Ui_MainWindow

# GUI'ler
from CVp2p import CVScanGUI
from CAp2p import CAScanGUI
from lnet_main import CAMeasurementApp

class MainApp(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # Tab 1 - Main
        self.lnet_gui = CAMeasurementApp()
        self.ui.tab.layout().addWidget(self.lnet_gui)

        # Tab 2 - CV
        self.cv_gui = CVScanGUI()
        self.ui.tab_2.layout().addWidget(self.cv_gui)

        # Tab 3 - CA
        self.ca_gui = CAScanGUI()
        self.ui.tab_3.layout().addWidget(self.ca_gui)

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    main_window = MainApp()
    main_window.show()
    sys.exit(app.exec_())
