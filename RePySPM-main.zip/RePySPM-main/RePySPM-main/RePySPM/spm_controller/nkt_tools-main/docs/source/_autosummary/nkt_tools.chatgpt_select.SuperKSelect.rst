nkt\_tools.chatgpt\_select.SuperKSelect
=======================================

.. currentmodule:: nkt_tools.chatgpt_select

.. autoclass:: SuperKSelect
   :members:
   :show-inheritance:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~SuperKSelect.__init__
      ~SuperKSelect.getCrystal1MaxWavelength
      ~SuperKSelect.getCrystal1MinWavelength
      ~SuperKSelect.getCrystal2MaxWavelength
      ~SuperKSelect.getCrystal2MinWavelength
      ~SuperKSelect.readMonitor1
      ~SuperKSelect.readMonitor2
      ~SuperKSelect.registerRead
      ~SuperKSelect.registerReadAscii
      ~SuperKSelect.registerWrite
      ~SuperKSelect.setMonitor1Gain
      ~SuperKSelect.setMonitor2Gain
      ~SuperKSelect.setMonitorSwitch
      ~SuperKSelect.setRfSwitch
   
   

   
   
   