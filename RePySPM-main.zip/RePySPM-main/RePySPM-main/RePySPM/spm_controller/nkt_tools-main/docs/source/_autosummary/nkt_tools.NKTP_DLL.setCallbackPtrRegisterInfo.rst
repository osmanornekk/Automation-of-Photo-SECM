nkt\_tools.NKTP\_DLL.setCallbackPtrRegisterInfo
===============================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: setCallbackPtrRegisterInfo