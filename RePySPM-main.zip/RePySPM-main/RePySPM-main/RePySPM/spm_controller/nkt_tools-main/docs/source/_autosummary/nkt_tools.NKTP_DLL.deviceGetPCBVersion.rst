nkt\_tools.NKTP\_DLL.deviceGetPCBVersion
========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetPCBVersion