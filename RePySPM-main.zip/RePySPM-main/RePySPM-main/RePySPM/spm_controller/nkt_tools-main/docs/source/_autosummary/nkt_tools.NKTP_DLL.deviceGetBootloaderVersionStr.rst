nkt\_tools.NKTP\_DLL.deviceGetBootloaderVersionStr
==================================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetBootloaderVersionStr