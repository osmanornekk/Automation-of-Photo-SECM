nkt\_tools.NKTP\_DLL.deviceGetFirmwareVersionStr
================================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetFirmwareVersionStr