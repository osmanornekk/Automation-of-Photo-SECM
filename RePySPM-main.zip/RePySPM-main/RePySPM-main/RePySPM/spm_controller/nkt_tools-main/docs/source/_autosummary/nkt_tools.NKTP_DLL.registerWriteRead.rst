nkt\_tools.NKTP\_DLL.registerWriteRead
======================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteRead