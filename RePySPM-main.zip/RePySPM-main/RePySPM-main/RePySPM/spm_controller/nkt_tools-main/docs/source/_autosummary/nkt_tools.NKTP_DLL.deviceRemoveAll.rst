nkt\_tools.NKTP\_DLL.deviceRemoveAll
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceRemoveAll