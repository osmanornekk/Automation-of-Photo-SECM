nkt\_tools.NKTP\_DLL.pointToPointPortData
=========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autoclass:: pointToPointPortData
   :members:
   :show-inheritance:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~pointToPointPortData.clientAddress
      ~pointToPointPortData.clientPort
      ~pointToPointPortData.hostAddress
      ~pointToPointPortData.hostPort
      ~pointToPointPortData.msTimeout
      ~pointToPointPortData.protocol
   
   