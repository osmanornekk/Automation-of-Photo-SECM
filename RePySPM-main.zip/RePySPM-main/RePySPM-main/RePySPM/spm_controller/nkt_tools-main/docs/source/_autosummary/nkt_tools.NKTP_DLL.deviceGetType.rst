nkt\_tools.NKTP\_DLL.deviceGetType
==================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetType