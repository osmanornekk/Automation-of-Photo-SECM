nkt\_tools.NKTP\_DLL.getPortStatus
==================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: getPortStatus