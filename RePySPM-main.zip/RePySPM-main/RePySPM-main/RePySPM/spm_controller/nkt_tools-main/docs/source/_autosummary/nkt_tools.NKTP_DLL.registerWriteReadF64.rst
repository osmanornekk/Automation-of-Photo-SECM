nkt\_tools.NKTP\_DLL.registerWriteReadF64
=========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteReadF64