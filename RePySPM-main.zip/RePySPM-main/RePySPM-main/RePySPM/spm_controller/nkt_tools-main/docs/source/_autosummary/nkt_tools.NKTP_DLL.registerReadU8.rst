nkt\_tools.NKTP\_DLL.registerReadU8
===================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerReadU8