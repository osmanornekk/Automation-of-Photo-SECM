nkt\_tools.NKTP\_DLL.deviceGetModuleSerialNumberStr
===================================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetModuleSerialNumberStr