nkt\_tools.NKTP\_DLL.registerReadU32
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerReadU32