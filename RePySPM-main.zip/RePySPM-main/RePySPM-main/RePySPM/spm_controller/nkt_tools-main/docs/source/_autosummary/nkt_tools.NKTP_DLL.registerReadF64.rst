nkt\_tools.NKTP\_DLL.registerReadF64
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerReadF64