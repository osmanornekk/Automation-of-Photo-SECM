nkt\_tools.NKTP\_DLL.registerWriteReadU64
=========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteReadU64