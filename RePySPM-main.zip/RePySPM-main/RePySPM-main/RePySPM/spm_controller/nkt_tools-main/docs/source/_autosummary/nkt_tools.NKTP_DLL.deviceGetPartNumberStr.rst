nkt\_tools.NKTP\_DLL.deviceGetPartNumberStr
===========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetPartNumberStr