nkt\_tools.NKTP\_DLL.registerReadF32
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerReadF32