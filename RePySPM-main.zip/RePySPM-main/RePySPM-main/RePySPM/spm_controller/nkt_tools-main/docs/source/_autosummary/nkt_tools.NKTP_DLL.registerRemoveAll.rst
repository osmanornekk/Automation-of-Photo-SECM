nkt\_tools.NKTP\_DLL.registerRemoveAll
======================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerRemoveAll