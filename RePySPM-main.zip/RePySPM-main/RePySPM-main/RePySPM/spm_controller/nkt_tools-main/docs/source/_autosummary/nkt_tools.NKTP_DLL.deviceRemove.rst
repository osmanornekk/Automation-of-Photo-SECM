nkt\_tools.NKTP\_DLL.deviceRemove
=================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceRemove