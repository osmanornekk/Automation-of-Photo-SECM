nkt\_tools.NKTP\_DLL.deviceGetErrorCode
=======================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetErrorCode