nkt\_tools.NKTP\_DLL.registerRemove
===================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerRemove