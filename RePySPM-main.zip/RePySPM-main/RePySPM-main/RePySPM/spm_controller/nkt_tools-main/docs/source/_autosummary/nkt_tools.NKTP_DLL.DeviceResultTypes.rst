nkt\_tools.NKTP\_DLL.DeviceResultTypes
======================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: DeviceResultTypes