nkt\_tools.NKTP\_DLL.registerReadS16
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerReadS16