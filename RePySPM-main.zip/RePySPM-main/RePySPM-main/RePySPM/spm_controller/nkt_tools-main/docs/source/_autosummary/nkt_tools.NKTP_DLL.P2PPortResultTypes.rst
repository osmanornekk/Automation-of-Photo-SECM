nkt\_tools.NKTP\_DLL.P2PPortResultTypes
=======================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: P2PPortResultTypes