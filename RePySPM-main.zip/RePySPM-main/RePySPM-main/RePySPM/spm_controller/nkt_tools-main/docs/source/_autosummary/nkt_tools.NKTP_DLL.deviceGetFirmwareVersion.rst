nkt\_tools.NKTP\_DLL.deviceGetFirmwareVersion
=============================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetFirmwareVersion