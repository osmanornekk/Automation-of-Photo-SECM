nkt\_tools.NKTP\_DLL.registerReadU64
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerReadU64