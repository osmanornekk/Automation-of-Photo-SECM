nkt\_tools.NKTP\_DLL.tParamSetStruct
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autoclass:: tParamSetStruct
   :members:
   :show-inheritance:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~tParamSetStruct.Denominator
      ~tParamSetStruct.ErrorHandler
      ~tParamSetStruct.FactoryVal
      ~tParamSetStruct.LLimit
      ~tParamSetStruct.Numerator
      ~tParamSetStruct.Offset
      ~tParamSetStruct.StartVal
      ~tParamSetStruct.ULimit
      ~tParamSetStruct.Unit
   
   