nkt\_tools.NKTP\_DLL.registerWriteReadU32
=========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteReadU32