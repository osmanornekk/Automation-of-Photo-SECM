nkt\_tools.NKTP\_DLL.setCallbackPtrPortInfo
===========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: setCallbackPtrPortInfo