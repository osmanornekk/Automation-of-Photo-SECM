nkt\_tools.NKTP\_DLL.openPorts
==============================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: openPorts