nkt\_tools.NKTP\_DLL.registerWriteF32
=====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteF32