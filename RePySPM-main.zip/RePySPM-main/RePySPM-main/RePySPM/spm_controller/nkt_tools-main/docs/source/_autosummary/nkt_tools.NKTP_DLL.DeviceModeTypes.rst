nkt\_tools.NKTP\_DLL.DeviceModeTypes
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: DeviceModeTypes