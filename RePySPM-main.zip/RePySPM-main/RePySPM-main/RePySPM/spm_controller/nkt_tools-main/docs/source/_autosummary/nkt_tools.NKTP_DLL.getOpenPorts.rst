nkt\_tools.NKTP\_DLL.getOpenPorts
=================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: getOpenPorts