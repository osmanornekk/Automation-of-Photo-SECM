nkt\_tools.NKTP\_DLL.RegisterDataTypes
======================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: RegisterDataTypes