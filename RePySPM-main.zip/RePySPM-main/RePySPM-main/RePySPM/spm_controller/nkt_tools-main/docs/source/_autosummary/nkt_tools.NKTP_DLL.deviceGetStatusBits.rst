nkt\_tools.NKTP\_DLL.deviceGetStatusBits
========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetStatusBits