nkt\_tools.NKTP\_DLL.RegisterPriorityTypes
==========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: RegisterPriorityTypes