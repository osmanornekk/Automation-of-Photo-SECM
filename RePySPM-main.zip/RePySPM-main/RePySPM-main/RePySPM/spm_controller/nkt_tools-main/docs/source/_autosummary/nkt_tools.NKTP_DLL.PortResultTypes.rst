nkt\_tools.NKTP\_DLL.PortResultTypes
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: PortResultTypes