nkt\_tools.NKTP\_DLL.setLegacyBusScanning
=========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: setLegacyBusScanning