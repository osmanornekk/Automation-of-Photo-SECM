nkt\_tools.NKTP\_DLL.registerWriteU64
=====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteU64