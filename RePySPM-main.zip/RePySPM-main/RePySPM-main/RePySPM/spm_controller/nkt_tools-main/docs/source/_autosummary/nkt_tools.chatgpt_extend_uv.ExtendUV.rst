nkt\_tools.chatgpt\_extend\_uv.ExtendUV
=======================================

.. currentmodule:: nkt_tools.chatgpt_extend_uv

.. autoclass:: ExtendUV
   :members:
   :show-inheritance:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~ExtendUV.__init__
      ~ExtendUV.get_max_wavelength
      ~ExtendUV.get_min_wavelength
      ~ExtendUV.get_status_bits
      ~ExtendUV.get_wavelength
      ~ExtendUV.set_max_wavelength
      ~ExtendUV.set_min_wavelength
      ~ExtendUV.set_wavelength
   
   

   
   
   