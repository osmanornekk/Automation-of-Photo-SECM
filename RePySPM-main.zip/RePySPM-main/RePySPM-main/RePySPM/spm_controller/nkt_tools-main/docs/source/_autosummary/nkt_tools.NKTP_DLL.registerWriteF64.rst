nkt\_tools.NKTP\_DLL.registerWriteF64
=====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteF64