nkt\_tools.NKTP\_DLL.deviceGetBootloaderVersion
===============================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetBootloaderVersion