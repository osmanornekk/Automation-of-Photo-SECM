nkt\_tools.NKTP\_DLL.deviceGetAllTypes
======================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetAllTypes