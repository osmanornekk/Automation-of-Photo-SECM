nkt\_tools.NKTP\_DLL.registerGetAll
===================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerGetAll