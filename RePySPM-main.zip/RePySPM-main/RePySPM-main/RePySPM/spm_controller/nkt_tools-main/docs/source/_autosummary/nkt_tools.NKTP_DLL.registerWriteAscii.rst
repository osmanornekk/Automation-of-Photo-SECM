nkt\_tools.NKTP\_DLL.registerWriteAscii
=======================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteAscii