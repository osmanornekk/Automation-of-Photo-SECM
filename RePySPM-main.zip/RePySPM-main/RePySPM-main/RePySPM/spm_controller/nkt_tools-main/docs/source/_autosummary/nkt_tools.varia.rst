nkt\_tools.varia
================

.. automodule:: nkt_tools.varia
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      Varia
   
   

   
   
   



