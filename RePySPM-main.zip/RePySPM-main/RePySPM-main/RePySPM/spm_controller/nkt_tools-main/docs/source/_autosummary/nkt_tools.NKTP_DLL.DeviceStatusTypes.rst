nkt\_tools.NKTP\_DLL.DeviceStatusTypes
======================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: DeviceStatusTypes