nkt\_tools.NKTP\_DLL.registerReadS32
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerReadS32