nkt\_tools.varia.Varia
======================

.. currentmodule:: nkt_tools.varia

.. autoclass:: Varia
   :members:
   :show-inheritance:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Varia.__init__
      ~Varia.demo_nkt_registerReads
      ~Varia.print_status
      ~Varia.read_all_properties
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~Varia.device_type
      ~Varia.long_setpoint
      ~Varia.module_address
      ~Varia.monitor_input
      ~Varia.nd_setpoint
      ~Varia.portname
      ~Varia.short_setpoint
      ~Varia.status_messages
   
   