nkt\_tools.NKTP\_DLL.registerWriteS64
=====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteS64