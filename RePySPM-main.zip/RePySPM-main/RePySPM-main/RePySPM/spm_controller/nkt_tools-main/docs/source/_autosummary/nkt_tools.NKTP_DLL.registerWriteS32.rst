nkt\_tools.NKTP\_DLL.registerWriteS32
=====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteS32