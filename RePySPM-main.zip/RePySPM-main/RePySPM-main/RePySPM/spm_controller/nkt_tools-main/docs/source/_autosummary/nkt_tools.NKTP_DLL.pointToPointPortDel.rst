nkt\_tools.NKTP\_DLL.pointToPointPortDel
========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: pointToPointPortDel