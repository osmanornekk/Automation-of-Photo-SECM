nkt\_tools.NKTP\_DLL.registerWriteS16
=====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteS16