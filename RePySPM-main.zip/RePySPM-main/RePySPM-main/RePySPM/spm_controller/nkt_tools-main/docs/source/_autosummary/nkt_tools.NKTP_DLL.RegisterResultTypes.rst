nkt\_tools.NKTP\_DLL.RegisterResultTypes
========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: RegisterResultTypes