nkt\_tools.NKTP\_DLL.setCallbackPtrDeviceInfo
=============================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: setCallbackPtrDeviceInfo