nkt\_tools.NKTP\_DLL.registerWriteS8
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteS8