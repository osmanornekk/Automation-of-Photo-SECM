nkt\_tools.NKTP\_DLL.registerCreate
===================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerCreate