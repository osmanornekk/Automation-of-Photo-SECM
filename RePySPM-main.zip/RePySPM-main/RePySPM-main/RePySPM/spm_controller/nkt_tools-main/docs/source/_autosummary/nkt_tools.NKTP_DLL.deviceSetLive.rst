nkt\_tools.NKTP\_DLL.deviceSetLive
==================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceSetLive