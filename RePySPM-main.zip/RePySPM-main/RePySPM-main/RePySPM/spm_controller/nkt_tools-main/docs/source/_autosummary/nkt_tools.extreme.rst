nkt\_tools.extreme
==================

.. automodule:: nkt_tools.extreme
   
   
   

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
      :toctree:
      :template: custom-class-template.rst
   
      Extreme
   
   

   
   
   



