nkt\_tools.NKTP\_DLL.registerExists
===================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerExists