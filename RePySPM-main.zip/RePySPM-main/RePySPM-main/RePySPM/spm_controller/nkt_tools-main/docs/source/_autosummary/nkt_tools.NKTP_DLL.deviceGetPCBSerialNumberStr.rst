nkt\_tools.NKTP\_DLL.deviceGetPCBSerialNumberStr
================================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceGetPCBSerialNumberStr