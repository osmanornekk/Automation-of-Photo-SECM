nkt\_tools.NKTP\_DLL.pointToPointPortAdd
========================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: pointToPointPortAdd