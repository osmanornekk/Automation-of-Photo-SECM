nkt\_tools.NKTP\_DLL.tDateTimeStruct
====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autoclass:: tDateTimeStruct
   :members:
   :show-inheritance:

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~tDateTimeStruct.Day
      ~tDateTimeStruct.Hour
      ~tDateTimeStruct.Min
      ~tDateTimeStruct.Month
      ~tDateTimeStruct.Sec
      ~tDateTimeStruct.Year
   
   