nkt\_tools.NKTP\_DLL.registerWriteU16
=====================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: registerWriteU16