nkt\_tools.NKTP\_DLL.deviceExists
=================================

.. currentmodule:: nkt_tools.NKTP_DLL

.. autofunction:: deviceExists